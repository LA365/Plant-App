/*
  # Hierarchical Plant Numbering System

  ## Summary
  This migration implements a hierarchical plant numbering system that shows parent-child relationships clearly.

  ## Changes Made

  1. **Schema Changes**
     - Convert `unique_number` from INTEGER to TEXT to support hierarchical format
     - Examples: P001, P001-C001 (corm from P001), P001-P002-S001 (seed from P001 x P002)

  2. **Numbering Functions**
     - `generate_hierarchical_plant_number()` - Generates proper hierarchical numbers based on parent relationships
     - Handles parent plants (P001), corms (P001-C001), cuttings (P001-C001), seeds (P001-S001 or P001-P002-S001)

  3. **Trigger Updates**
     - Updates the plant number assignment trigger to use new hierarchical system
     - Maintains backward compatibility with existing plants

  4. **Data Migration**
     - Converts existing integer unique_numbers to new text format (P0001, P0002, etc.)
     - Preserves all existing data

  ## Important Notes
  - Parent-child relationships from the `relationships` table drive the numbering
  - Numbers are assigned on INSERT and cannot be changed after creation
  - The system maintains uniqueness per user
*/

-- Step 1: Backup existing unique numbers and convert to text format
DO $$
BEGIN
  -- Add temporary column to store converted values
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'unique_number_text'
  ) THEN
    ALTER TABLE plants ADD COLUMN unique_number_text TEXT;
  END IF;

  -- Convert existing integer numbers to P#### format
  UPDATE plants
  SET unique_number_text = 'P' || LPAD(unique_number::text, 3, '0')
  WHERE unique_number_text IS NULL;
END $$;

-- Step 2: Drop old constraints and column, rename new column
DO $$
BEGIN
  -- Drop the old index
  DROP INDEX IF EXISTS idx_plants_unique_number;

  -- Drop the old column
  ALTER TABLE plants DROP COLUMN IF EXISTS unique_number;

  -- Rename new column
  ALTER TABLE plants RENAME COLUMN unique_number_text TO unique_number;

  -- Add NOT NULL constraint
  ALTER TABLE plants ALTER COLUMN unique_number SET NOT NULL;
END $$;

-- Step 3: Create new index on text-based unique_number
CREATE INDEX IF NOT EXISTS idx_plants_unique_number_text ON plants(user_id, unique_number);

-- Step 4: Create function to generate hierarchical plant numbers
CREATE OR REPLACE FUNCTION generate_hierarchical_plant_number(p_user_id UUID, p_plant_id BIGINT)
RETURNS TEXT AS $$
DECLARE
  v_parent_rel RECORD;
  v_parent_plant RECORD;
  v_parent_b_plant RECORD;
  v_relation_type TEXT;
  v_parent_number TEXT;
  v_parent_b_number TEXT;
  v_next_child_number INTEGER;
  v_prefix TEXT;
  v_result TEXT;
BEGIN
  -- Check if this plant has a parent relationship
  SELECT * INTO v_parent_rel
  FROM relationships
  WHERE child_id = p_plant_id
  AND relation_type IN ('CormFrom', 'CuttingFrom', 'SeedFrom')
  LIMIT 1;

  -- If no parent relationship, this is a root plant
  IF NOT FOUND THEN
    -- Get next sequential parent plant number
    SELECT COALESCE(MAX(SUBSTRING(unique_number FROM '^P(\d+)$')::INTEGER), 0) + 1
    INTO v_next_child_number
    FROM plants
    WHERE user_id = p_user_id
    AND unique_number ~ '^P\d+$';  -- Only root plants (P### format)

    RETURN 'P' || LPAD(v_next_child_number::TEXT, 3, '0');
  END IF;

  -- Get parent plant information
  SELECT unique_number INTO v_parent_plant
  FROM plants
  WHERE id = v_parent_rel.parent_id;

  v_relation_type := v_parent_rel.relation_type;
  v_parent_number := v_parent_plant.unique_number;

  -- Determine prefix based on relation type
  CASE v_relation_type
    WHEN 'CormFrom' THEN v_prefix := 'C';
    WHEN 'CuttingFrom' THEN v_prefix := 'C';
    WHEN 'SeedFrom' THEN v_prefix := 'S';
    ELSE v_prefix := 'X';
  END CASE;

  -- For seeds, check if there's a second parent (cross breeding)
  IF v_relation_type = 'SeedFrom' THEN
    SELECT * INTO v_parent_b_plant
    FROM relationships r
    JOIN plants p ON r.parent_id = p.id
    WHERE r.child_id = p_plant_id
    AND r.relation_type IN ('PollenFather', 'PollenMother')
    AND r.parent_id != v_parent_rel.parent_id
    LIMIT 1;

    IF FOUND THEN
      v_parent_b_number := v_parent_b_plant.unique_number;

      -- Count existing seeds from this cross
      SELECT COALESCE(MAX(SUBSTRING(p.unique_number FROM '-S(\d+)$')::INTEGER), 0) + 1
      INTO v_next_child_number
      FROM plants p
      WHERE p.user_id = p_user_id
      AND p.unique_number ~ ('^' || v_parent_number || '-' || v_parent_b_number || '-S\d+$');

      RETURN v_parent_number || '-' || v_parent_b_number || '-S' || LPAD(v_next_child_number::TEXT, 3, '0');
    END IF;
  END IF;

  -- Single parent (corm, cutting, or seed from one parent)
  -- Count existing children of this type from this parent
  SELECT COALESCE(MAX(SUBSTRING(p.unique_number FROM '-' || v_prefix || '(\d+)$')::INTEGER), 0) + 1
  INTO v_next_child_number
  FROM plants p
  WHERE p.user_id = p_user_id
  AND p.unique_number ~ ('^' || v_parent_number || '-' || v_prefix || '\d+$');

  RETURN v_parent_number || '-' || v_prefix || LPAD(v_next_child_number::TEXT, 3, '0');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Step 5: Update the trigger function to use hierarchical numbering
CREATE OR REPLACE FUNCTION assign_plant_unique_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.unique_number IS NULL OR NEW.unique_number = '' THEN
    -- Generate hierarchical number (will be called after plant is inserted and has an ID)
    -- For now, assign a temporary placeholder
    NEW.unique_number := 'TEMP-' || gen_random_uuid()::TEXT;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Step 6: Create trigger to assign final hierarchical number after insert
CREATE OR REPLACE FUNCTION finalize_plant_unique_number()
RETURNS TRIGGER AS $$
DECLARE
  v_new_number TEXT;
BEGIN
  -- Only process if number is still temporary
  IF NEW.unique_number LIKE 'TEMP-%' THEN
    v_new_number := generate_hierarchical_plant_number(NEW.user_id, NEW.id);

    UPDATE plants
    SET unique_number = v_new_number
    WHERE id = NEW.id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trigger_finalize_plant_unique_number ON plants;

-- Create new trigger to run after insert
CREATE TRIGGER trigger_finalize_plant_unique_number
  AFTER INSERT ON plants
  FOR EACH ROW
  WHEN (NEW.unique_number LIKE 'TEMP-%')
  EXECUTE FUNCTION finalize_plant_unique_number();
