/*
  # Create Reference Tables for Lookup Lists

  1. New Tables
    - `genus_options` - List of plant genus names
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)
    
    - `nutrient_types` - List of nutrient/fertilizer types
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)
    
    - `medium_options` - List of growing medium types
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)
    
    - `action_types` - List of activity action types
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)
    
    - `location_zones` - List of location/zone options
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)
    
    - `finance_categories` - List of finance categories
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `type` (text) - 'income' or 'expense'
      - `created_at` (timestamptz)
    
    - `tags` - List of tags for plants
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all reference tables
    - Add policies for authenticated users to read
    - Add policies for authenticated users to insert/update/delete
*/

-- Genus Options
CREATE TABLE IF NOT EXISTS genus_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE genus_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read genus options"
  ON genus_options FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert genus options"
  ON genus_options FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update genus options"
  ON genus_options FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete genus options"
  ON genus_options FOR DELETE
  TO authenticated
  USING (true);

-- Nutrient Types
CREATE TABLE IF NOT EXISTS nutrient_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE nutrient_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read nutrient types"
  ON nutrient_types FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert nutrient types"
  ON nutrient_types FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update nutrient types"
  ON nutrient_types FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete nutrient types"
  ON nutrient_types FOR DELETE
  TO authenticated
  USING (true);

-- Medium Options
CREATE TABLE IF NOT EXISTS medium_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE medium_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read medium options"
  ON medium_options FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert medium options"
  ON medium_options FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update medium options"
  ON medium_options FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete medium options"
  ON medium_options FOR DELETE
  TO authenticated
  USING (true);

-- Action Types
CREATE TABLE IF NOT EXISTS action_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE action_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read action types"
  ON action_types FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert action types"
  ON action_types FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update action types"
  ON action_types FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete action types"
  ON action_types FOR DELETE
  TO authenticated
  USING (true);

-- Location Zones
CREATE TABLE IF NOT EXISTS location_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE location_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read location zones"
  ON location_zones FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert location zones"
  ON location_zones FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update location zones"
  ON location_zones FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete location zones"
  ON location_zones FOR DELETE
  TO authenticated
  USING (true);

-- Finance Categories
CREATE TABLE IF NOT EXISTS finance_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE finance_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read finance categories"
  ON finance_categories FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert finance categories"
  ON finance_categories FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update finance categories"
  ON finance_categories FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete finance categories"
  ON finance_categories FOR DELETE
  TO authenticated
  USING (true);

-- Tags
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read tags"
  ON tags FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert tags"
  ON tags FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update tags"
  ON tags FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can delete tags"
  ON tags FOR DELETE
  TO authenticated
  USING (true);

-- Insert default action types
INSERT INTO action_types (name) VALUES
  ('Repot'),
  ('Flush'),
  ('Corm Harvest'),
  ('Cutting'),
  ('Feeding'),
  ('Sale'),
  ('Observation'),
  ('Pollination'),
  ('Seed Harvest'),
  ('Germination'),
  ('Pest Treatment'),
  ('Photo')
ON CONFLICT (name) DO NOTHING;

-- Insert default finance categories
INSERT INTO finance_categories (name, type) VALUES
  ('Fertilizer', 'expense'),
  ('Medium', 'expense'),
  ('Pots', 'expense'),
  ('Tools', 'expense'),
  ('Misc', 'expense'),
  ('Sales', 'income')
ON CONFLICT (name) DO NOTHING;