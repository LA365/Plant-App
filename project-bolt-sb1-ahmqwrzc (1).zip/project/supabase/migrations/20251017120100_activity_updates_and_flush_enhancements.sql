/*
  # Activity Updates and Flush Date Enhancements

  ## Summary
  Enhances activity management with edit/delete support and improves flush date tracking.

  ## Changes Made

  1. **New Action Types**
     - Added 'Report' and 'Observation' action types that trigger flush date updates

  2. **Flush Date Triggers**
     - Report and Observation activities now update last_flush_date
     - New plants automatically get last_flush_date set to creation date
     - Flush date updates when activities are edited or added

  3. **Activity Update Handling**
     - Updated triggers to handle activity updates (not just inserts)
     - Recalculates plant data when activities are modified or deleted
     - Ensures data consistency when users edit past activities

  4. **Data Integrity**
     - Added triggers to maintain consistency when activities are deleted
     - Updates all dependent plant fields when activities change

  ## Important Notes
  - Editing or deleting activities will recalculate plant statistics
  - Flush dates are updated based on activity dates, not current time
  - All flush-related actions (Flush, Report, Observation) reset the flush timer
*/

-- Add Report action type if it doesn't exist
INSERT INTO action_types (name, requires_quantity, requires_medium, requires_nutrient, requires_cost, creates_children)
VALUES ('Report', false, false, false, false, false)
ON CONFLICT (name) DO NOTHING;

-- Ensure Observation exists with proper configuration
INSERT INTO action_types (name, requires_quantity, requires_medium, requires_nutrient, requires_cost, creates_children)
VALUES ('Observation', false, false, false, false, false)
ON CONFLICT (name) DO UPDATE SET
  requires_quantity = false,
  requires_medium = false,
  requires_nutrient = false,
  requires_cost = false,
  creates_children = false;

-- Update the plant update trigger to handle Report and Observation
CREATE OR REPLACE FUNCTION update_plant_from_activity()
RETURNS TRIGGER AS $$
DECLARE
  action_name TEXT;
BEGIN
  -- Get action type name
  SELECT name INTO action_name
  FROM action_types
  WHERE id = NEW.action_type_id;

  -- Update last_flush_date for any flush-related activity
  IF action_name IN ('Flush', 'Flushing', 'Report', 'Observation') THEN
    UPDATE plants
    SET last_flush_date = NEW.date::date
    WHERE id = NEW.plant_id
    AND (last_flush_date IS NULL OR NEW.date::date > last_flush_date);
  END IF;

  -- Update last_repot_date if this is a repotting activity
  IF action_name IN ('Repot', 'Repotting') THEN
    UPDATE plants
    SET last_repot_date = NEW.date::date,
        current_medium_id = COALESCE(NEW.medium_used_id, current_medium_id)
    WHERE id = NEW.plant_id
    AND (last_repot_date IS NULL OR NEW.date::date > last_repot_date);
  END IF;

  -- Update total_corms_produced if this is a harvest with quantity
  IF action_name IN ('Corm Harvest', 'Harvest Corms', 'Harvesting') AND NEW.quantity_count > 0 THEN
    UPDATE plants
    SET total_corms_produced = total_corms_produced + NEW.quantity_count
    WHERE id = NEW.plant_id;
  END IF;

  -- Update plant status to Sold if action is Sale
  IF action_name = 'Sale' THEN
    UPDATE plants
    SET status = 'Sold',
        sold_date = NEW.date::date
    WHERE id = NEW.plant_id
    AND status != 'Sold';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to recalculate plant data when activity is updated
CREATE OR REPLACE FUNCTION recalculate_plant_on_activity_change()
RETURNS TRIGGER AS $$
DECLARE
  action_name_old TEXT;
  action_name_new TEXT;
  plant_id_to_update BIGINT;
  latest_flush_date DATE;
  latest_repot_date DATE;
BEGIN
  -- Determine which plant to update
  IF TG_OP = 'DELETE' THEN
    plant_id_to_update := OLD.plant_id;
    SELECT name INTO action_name_old FROM action_types WHERE id = OLD.action_type_id;
  ELSIF TG_OP = 'UPDATE' THEN
    plant_id_to_update := NEW.plant_id;
    SELECT name INTO action_name_old FROM action_types WHERE id = OLD.action_type_id;
    SELECT name INTO action_name_new FROM action_types WHERE id = NEW.action_type_id;
  END IF;

  -- Recalculate last_flush_date from all flush-related activities
  IF (TG_OP = 'DELETE' AND action_name_old IN ('Flush', 'Flushing', 'Report', 'Observation'))
     OR (TG_OP = 'UPDATE' AND (action_name_old IN ('Flush', 'Flushing', 'Report', 'Observation')
                               OR action_name_new IN ('Flush', 'Flushing', 'Report', 'Observation'))) THEN

    SELECT MAX(al.date::date) INTO latest_flush_date
    FROM activity_log al
    JOIN action_types at ON al.action_type_id = at.id
    WHERE al.plant_id = plant_id_to_update
    AND at.name IN ('Flush', 'Flushing', 'Report', 'Observation');

    UPDATE plants
    SET last_flush_date = latest_flush_date
    WHERE id = plant_id_to_update;
  END IF;

  -- Recalculate last_repot_date from all repot activities
  IF (TG_OP = 'DELETE' AND action_name_old IN ('Repot', 'Repotting'))
     OR (TG_OP = 'UPDATE' AND (action_name_old IN ('Repot', 'Repotting')
                               OR action_name_new IN ('Repot', 'Repotting'))) THEN

    SELECT MAX(al.date::date) INTO latest_repot_date
    FROM activity_log al
    JOIN action_types at ON al.action_type_id = at.id
    WHERE al.plant_id = plant_id_to_update
    AND at.name IN ('Repot', 'Repotting');

    UPDATE plants
    SET last_repot_date = latest_repot_date
    WHERE id = plant_id_to_update;
  END IF;

  -- Recalculate total_corms_produced
  IF (TG_OP = 'DELETE' AND action_name_old IN ('Corm Harvest', 'Harvest Corms', 'Harvesting'))
     OR (TG_OP = 'UPDATE' AND (action_name_old IN ('Corm Harvest', 'Harvest Corms', 'Harvesting')
                               OR action_name_new IN ('Corm Harvest', 'Harvest Corms', 'Harvesting'))) THEN

    UPDATE plants
    SET total_corms_produced = (
      SELECT COALESCE(SUM(al.quantity_count), 0)
      FROM activity_log al
      JOIN action_types at ON al.action_type_id = at.id
      WHERE al.plant_id = plant_id_to_update
      AND at.name IN ('Corm Harvest', 'Harvest Corms', 'Harvesting')
    )
    WHERE id = plant_id_to_update;
  END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop old triggers if they exist
DROP TRIGGER IF EXISTS trigger_recalculate_on_activity_update ON activity_log;
DROP TRIGGER IF EXISTS trigger_recalculate_on_activity_delete ON activity_log;

-- Create triggers for activity updates and deletes
CREATE TRIGGER trigger_recalculate_on_activity_update
  AFTER UPDATE ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION recalculate_plant_on_activity_change();

CREATE TRIGGER trigger_recalculate_on_activity_delete
  AFTER DELETE ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION recalculate_plant_on_activity_change();

-- Function to set initial flush date on new plants
CREATE OR REPLACE FUNCTION set_initial_plant_dates()
RETURNS TRIGGER AS $$
BEGIN
  -- Set last_flush_date to today if not specified
  IF NEW.last_flush_date IS NULL THEN
    NEW.last_flush_date := CURRENT_DATE;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to set initial dates on plant creation
DROP TRIGGER IF EXISTS trigger_set_initial_plant_dates ON plants;
CREATE TRIGGER trigger_set_initial_plant_dates
  BEFORE INSERT ON plants
  FOR EACH ROW
  EXECUTE FUNCTION set_initial_plant_dates();
