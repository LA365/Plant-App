/*
  # Create Activity Log Table

  1. New Tables
    - `activity_log` - Track all plant activities
      - `id` (bigserial, primary key)
      - `user_id` (uuid) - Owner of the activity
      - `plant_id` (bigint) - Reference to plants
      - `date` (timestamptz) - Date/time of activity
      - `action_type_id` (uuid) - Reference to action_types
      - `details` (text) - Activity notes/details
      - `medium_used_id` (uuid) - Reference to medium_options (optional)
      - `nutrient_type_id` (uuid) - Reference to nutrient_types (optional)
      - `quantity_count` (integer) - For corms, cuttings, etc.
      - `cost_income` (decimal) - Financial amount (DKK)
      - `photo_link` (text) - Link to photo
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on activity_log table
    - Users can only access activities for their own plants

  3. Indexes
    - Index on user_id for fast user queries
    - Index on plant_id for plant-specific queries
    - Index on date for chronological sorting
    - Index on action_type_id for filtering by action type

  4. Important Notes
    - Triggers will be created in a separate migration to update plants table
*/

CREATE TABLE IF NOT EXISTS activity_log (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plant_id bigint NOT NULL REFERENCES plants(id) ON DELETE CASCADE,
  date timestamptz DEFAULT now(),
  action_type_id uuid NOT NULL REFERENCES action_types(id),
  details text,
  medium_used_id uuid REFERENCES medium_options(id),
  nutrient_type_id uuid REFERENCES nutrient_types(id),
  quantity_count integer DEFAULT 0,
  cost_income decimal(10, 2) DEFAULT 0,
  photo_link text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_activity_log_user_id ON activity_log(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_plant_id ON activity_log(plant_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_date ON activity_log(date DESC);
CREATE INDEX IF NOT EXISTS idx_activity_log_action_type_id ON activity_log(action_type_id);

-- Enable RLS
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own activity logs"
  ON activity_log FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activity logs"
  ON activity_log FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = activity_log.plant_id
      AND plants.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own activity logs"
  ON activity_log FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own activity logs"
  ON activity_log FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Trigger to automatically update updated_at
CREATE TRIGGER update_activity_log_updated_at
  BEFORE UPDATE ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();