/*
  # Fix Unique Number System, Add Plant Costs, and User Preferences

  ## Summary
  This migration fixes the unique plant numbering system to ensure numbers are never reused,
  adds cost tracking for plants, and creates a user preferences system for field visibility.

  ## Changes Made

  1. **Plant Number Sequence Table**
     - Creates table to track all used plant numbers permanently
     - Ensures numbers are never reused even if plants are deleted
     - Maintains separate sequences per user and number type

  2. **Plant Cost Tracking**
     - Adds `purchase_cost` column for tracking initial plant purchase cost
     - Adds `propagation_cost` column for tracking propagation material costs
     - Both nullable decimal fields with 2 decimal places

  3. **User Preferences System**
     - Creates `user_preferences` table for global field visibility settings
     - Adds `plant_field_overrides` JSONB column to plants for per-plant overrides
     - Stores preferences for Origin, Status, Location, Medium, Nutrients, Maintenance

  4. **Unique Number Constraints**
     - Adds unique constraint on unique_number per user
     - Updates trigger to check sequence table before assigning numbers
     - Prevents number reuse with permanent reservation

  ## Important Notes
  - All existing plant numbers are preserved
  - Deleted plants maintain their numbers in the sequence table
  - User preferences default to all fields enabled
  - Per-plant overrides are optional and override global settings
*/

-- ============================================================================
-- STEP 1: Create Plant Number Sequence Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS plant_number_sequence (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  unique_number text NOT NULL,
  plant_id bigint REFERENCES plants(id) ON DELETE SET NULL,
  assigned_at timestamptz DEFAULT now(),
  is_active boolean DEFAULT true,
  UNIQUE(user_id, unique_number)
);

CREATE INDEX IF NOT EXISTS idx_plant_number_sequence_user_id ON plant_number_sequence(user_id);
CREATE INDEX IF NOT EXISTS idx_plant_number_sequence_unique_number ON plant_number_sequence(user_id, unique_number);

-- Enable RLS
ALTER TABLE plant_number_sequence ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own number sequences"
  ON plant_number_sequence FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own number sequences"
  ON plant_number_sequence FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Populate sequence table with existing plant numbers
INSERT INTO plant_number_sequence (user_id, unique_number, plant_id, is_active)
SELECT user_id, unique_number, id, true
FROM plants
WHERE unique_number IS NOT NULL AND unique_number NOT LIKE 'TEMP-%'
ON CONFLICT (user_id, unique_number) DO NOTHING;

-- ============================================================================
-- STEP 2: Add Plant Cost Columns
-- ============================================================================

DO $$
BEGIN
  -- Add purchase_cost column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'purchase_cost'
  ) THEN
    ALTER TABLE plants ADD COLUMN purchase_cost numeric(10, 2) DEFAULT NULL;
  END IF;

  -- Add propagation_cost column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'propagation_cost'
  ) THEN
    ALTER TABLE plants ADD COLUMN propagation_cost numeric(10, 2) DEFAULT NULL;
  END IF;

  -- Add plant_field_overrides column for per-plant preferences
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'plant_field_overrides'
  ) THEN
    ALTER TABLE plants ADD COLUMN plant_field_overrides jsonb DEFAULT NULL;
  END IF;
END $$;

-- ============================================================================
-- STEP 3: Create User Preferences Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Field visibility settings
  show_origin boolean DEFAULT true,
  show_status boolean DEFAULT true,
  show_location boolean DEFAULT true,
  show_medium boolean DEFAULT true,
  show_nutrients boolean DEFAULT true,
  show_maintenance_thresholds boolean DEFAULT true,

  -- Default maintenance threshold values
  default_flush_yellow_days integer DEFAULT 30,
  default_flush_red_days integer DEFAULT 60,
  default_repot_yellow_months integer DEFAULT 6,
  default_repot_red_months integer DEFAULT 12,

  -- Display preferences
  plant_name_format text DEFAULT 'number_genus_species',
  default_plant_sort text DEFAULT 'created_desc',

  -- Notification preferences
  enable_care_reminders boolean DEFAULT true,
  reminder_advance_days integer DEFAULT 3,

  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  UNIQUE(user_id)
);

CREATE INDEX IF NOT EXISTS idx_user_preferences_user_id ON user_preferences(user_id);

-- Enable RLS
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own preferences"
  ON user_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create default preferences for existing users
INSERT INTO user_preferences (user_id)
SELECT DISTINCT user_id FROM plants
ON CONFLICT (user_id) DO NOTHING;

-- Trigger to update updated_at timestamp
CREATE TRIGGER update_user_preferences_updated_at
  BEFORE UPDATE ON user_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- STEP 4: Add Unique Constraint to Plant Numbers
-- ============================================================================

-- Add unique constraint on unique_number per user (if not exists)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'plants_user_id_unique_number_key'
  ) THEN
    ALTER TABLE plants ADD CONSTRAINT plants_user_id_unique_number_key
      UNIQUE (user_id, unique_number);
  END IF;
END $$;

-- ============================================================================
-- STEP 5: Update Hierarchical Number Generation Function
-- ============================================================================

CREATE OR REPLACE FUNCTION generate_hierarchical_plant_number_v2(p_user_id UUID, p_plant_id BIGINT)
RETURNS TEXT AS $$
DECLARE
  v_parent_rel RECORD;
  v_parent_plant RECORD;
  v_parent_b_plant RECORD;
  v_relation_type TEXT;
  v_parent_number TEXT;
  v_parent_b_number TEXT;
  v_next_child_number INTEGER;
  v_prefix TEXT;
  v_result TEXT;
  v_exists BOOLEAN;
BEGIN
  -- Check if this plant has a parent relationship
  SELECT * INTO v_parent_rel
  FROM relationships
  WHERE child_id = p_plant_id
  AND relation_type IN ('CormFrom', 'CuttingFrom', 'SeedFrom')
  LIMIT 1;

  -- If no parent relationship, this is a root plant
  IF NOT FOUND THEN
    -- Get next sequential parent plant number from sequence table
    LOOP
      SELECT COALESCE(MAX(SUBSTRING(unique_number FROM '^P(\d+)$')::INTEGER), 0) + 1
      INTO v_next_child_number
      FROM plant_number_sequence
      WHERE user_id = p_user_id
      AND unique_number ~ '^P\d+$';  -- Only root plants (P### format)

      v_result := 'P' || LPAD(v_next_child_number::TEXT, 3, '0');

      -- Check if this number is already used
      SELECT EXISTS(
        SELECT 1 FROM plant_number_sequence
        WHERE user_id = p_user_id AND unique_number = v_result
      ) INTO v_exists;

      EXIT WHEN NOT v_exists;

      -- If exists, increment and try again
      v_next_child_number := v_next_child_number + 1;
    END LOOP;

    -- Reserve this number in the sequence
    INSERT INTO plant_number_sequence (user_id, unique_number, plant_id)
    VALUES (p_user_id, v_result, p_plant_id)
    ON CONFLICT (user_id, unique_number) DO NOTHING;

    RETURN v_result;
  END IF;

  -- Get parent plant information
  SELECT unique_number INTO v_parent_plant
  FROM plants
  WHERE id = v_parent_rel.parent_id;

  v_relation_type := v_parent_rel.relation_type;
  v_parent_number := v_parent_plant.unique_number;

  -- Determine prefix based on relation type
  CASE v_relation_type
    WHEN 'CormFrom' THEN v_prefix := 'C';
    WHEN 'CuttingFrom' THEN v_prefix := 'T';  -- Changed from C to T for cutting to differentiate
    WHEN 'SeedFrom' THEN v_prefix := 'S';
    ELSE v_prefix := 'X';
  END CASE;

  -- For seeds, check if there's a second parent (cross breeding)
  IF v_relation_type = 'SeedFrom' THEN
    SELECT * INTO v_parent_b_plant
    FROM relationships r
    JOIN plants p ON r.parent_id = p.id
    WHERE r.child_id = p_plant_id
    AND r.relation_type IN ('PollenFather', 'PollenMother')
    AND r.parent_id != v_parent_rel.parent_id
    LIMIT 1;

    IF FOUND THEN
      v_parent_b_number := v_parent_b_plant.unique_number;

      -- Find next available number for this cross
      LOOP
        SELECT COALESCE(MAX(SUBSTRING(pns.unique_number FROM '-S(\d+)$')::INTEGER), 0) + 1
        INTO v_next_child_number
        FROM plant_number_sequence pns
        WHERE pns.user_id = p_user_id
        AND pns.unique_number ~ ('^' || v_parent_number || '-' || v_parent_b_number || '-S\d+$');

        v_result := v_parent_number || '-' || v_parent_b_number || '-S' || LPAD(v_next_child_number::TEXT, 3, '0');

        -- Check if this number is already used
        SELECT EXISTS(
          SELECT 1 FROM plant_number_sequence
          WHERE user_id = p_user_id AND unique_number = v_result
        ) INTO v_exists;

        EXIT WHEN NOT v_exists;

        v_next_child_number := v_next_child_number + 1;
      END LOOP;

      -- Reserve this number
      INSERT INTO plant_number_sequence (user_id, unique_number, plant_id)
      VALUES (p_user_id, v_result, p_plant_id)
      ON CONFLICT (user_id, unique_number) DO NOTHING;

      RETURN v_result;
    END IF;
  END IF;

  -- Single parent (corm, cutting, or seed from one parent)
  -- Find next available number
  LOOP
    SELECT COALESCE(MAX(SUBSTRING(pns.unique_number FROM '-' || v_prefix || '(\d+)$')::INTEGER), 0) + 1
    INTO v_next_child_number
    FROM plant_number_sequence pns
    WHERE pns.user_id = p_user_id
    AND pns.unique_number ~ ('^' || v_parent_number || '-' || v_prefix || '\d+$');

    v_result := v_parent_number || '-' || v_prefix || LPAD(v_next_child_number::TEXT, 3, '0');

    -- Check if this number is already used
    SELECT EXISTS(
      SELECT 1 FROM plant_number_sequence
      WHERE user_id = p_user_id AND unique_number = v_result
    ) INTO v_exists;

    EXIT WHEN NOT v_exists;

    v_next_child_number := v_next_child_number + 1;
  END LOOP;

  -- Reserve this number
  INSERT INTO plant_number_sequence (user_id, unique_number, plant_id)
  VALUES (p_user_id, v_result, p_plant_id)
  ON CONFLICT (user_id, unique_number) DO NOTHING;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- STEP 6: Update Finalize Plant Number Function
-- ============================================================================

CREATE OR REPLACE FUNCTION finalize_plant_unique_number_v2()
RETURNS TRIGGER AS $$
DECLARE
  v_new_number TEXT;
BEGIN
  -- Only process if number is still temporary
  IF NEW.unique_number LIKE 'TEMP-%' THEN
    v_new_number := generate_hierarchical_plant_number_v2(NEW.user_id, NEW.id);

    UPDATE plants
    SET unique_number = v_new_number
    WHERE id = NEW.id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger with new function
DROP TRIGGER IF EXISTS trigger_finalize_plant_unique_number ON plants;

CREATE TRIGGER trigger_finalize_plant_unique_number
  AFTER INSERT ON plants
  FOR EACH ROW
  WHEN (NEW.unique_number LIKE 'TEMP-%')
  EXECUTE FUNCTION finalize_plant_unique_number_v2();

-- ============================================================================
-- STEP 7: Create Function to Calculate Plant Profitability
-- ============================================================================

CREATE OR REPLACE FUNCTION calculate_plant_profitability(p_plant_id BIGINT)
RETURNS TABLE(
  total_cost numeric,
  total_income numeric,
  net_profit numeric,
  roi_percentage numeric
) AS $$
DECLARE
  v_plant RECORD;
  v_total_cost numeric := 0;
  v_total_income numeric := 0;
  v_child_income numeric := 0;
BEGIN
  -- Get plant costs
  SELECT
    COALESCE(purchase_cost, 0) + COALESCE(propagation_cost, 0) as plant_cost
  INTO v_plant
  FROM plants
  WHERE id = p_plant_id;

  v_total_cost := v_plant.plant_cost;

  -- Get direct income from activities
  SELECT COALESCE(SUM(cost_income), 0)
  INTO v_total_income
  FROM activity_log
  WHERE plant_id = p_plant_id
  AND cost_income > 0;

  -- Get income from child plants (sold corms, cuttings, seeds)
  SELECT COALESCE(SUM(al.cost_income), 0)
  INTO v_child_income
  FROM relationships r
  JOIN activity_log al ON al.plant_id = r.child_id
  WHERE r.parent_id = p_plant_id
  AND al.cost_income > 0;

  v_total_income := v_total_income + v_child_income;

  RETURN QUERY SELECT
    v_total_cost,
    v_total_income,
    v_total_income - v_total_cost as net_profit,
    CASE
      WHEN v_total_cost > 0 THEN ((v_total_income - v_total_cost) / v_total_cost * 100)
      ELSE 0
    END as roi_percentage;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
