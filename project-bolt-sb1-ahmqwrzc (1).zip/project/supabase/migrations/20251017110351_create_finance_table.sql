/*
  # Create Finance Table

  1. New Tables
    - `finance` - Track income and expenses
      - `id` (bigserial, primary key)
      - `user_id` (uuid) - Owner of the finance record
      - `date` (date) - Date of transaction
      - `type` (text) - Income or Expense
      - `category_id` (uuid) - Reference to finance_categories
      - `description` (text) - Transaction description
      - `amount` (decimal) - Amount in DKK (positive value)
      - `related_plant_id` (bigint) - Optional reference to plants
      - `payment_method` (text) - Payment method
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on finance table
    - Users can only access their own finance records

  3. Indexes
    - Index on user_id for fast user queries
    - Index on date for chronological sorting
    - Index on type for filtering by income/expense
    - Index on category_id for category filtering
*/

CREATE TABLE IF NOT EXISTS finance (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date date DEFAULT CURRENT_DATE,
  type text NOT NULL CHECK (type IN ('Income', 'Expense')),
  category_id uuid NOT NULL REFERENCES finance_categories(id),
  description text,
  amount decimal(10, 2) NOT NULL CHECK (amount >= 0),
  related_plant_id bigint REFERENCES plants(id) ON DELETE SET NULL,
  payment_method text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_finance_user_id ON finance(user_id);
CREATE INDEX IF NOT EXISTS idx_finance_date ON finance(date DESC);
CREATE INDEX IF NOT EXISTS idx_finance_type ON finance(type);
CREATE INDEX IF NOT EXISTS idx_finance_category_id ON finance(category_id);

-- Enable RLS
ALTER TABLE finance ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own finance records"
  ON finance FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own finance records"
  ON finance FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own finance records"
  ON finance FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own finance records"
  ON finance FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Trigger to automatically update updated_at
CREATE TRIGGER update_finance_updated_at
  BEFORE UPDATE ON finance
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();