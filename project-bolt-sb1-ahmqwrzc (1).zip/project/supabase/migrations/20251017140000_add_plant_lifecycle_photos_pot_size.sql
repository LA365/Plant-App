/*
  # Add Plant Lifecycle Status, Photos, and Pot Size

  ## Summary
  This migration adds comprehensive plant lifecycle tracking with plant types and growth stages,
  photo management with thumbnails, and pot size tracking to enhance plant management capabilities.

  ## Changes Made

  1. **Plant Type Reference Table**
     - Creates `plant_types` table for standardized plant type options
     - Default types: Corm, Cutting, Sideshot, Seedling, Mature Plant, Division
     - Users can add custom plant types

  2. **Growth Stage Reference Table**
     - Creates `growth_stages` table for lifecycle stage tracking
     - Default stages: Vegetative, Pre-Bloom, Blooming, Post-Bloom, Dormant, Establishing
     - Users can add custom growth stages

  3. **New Plant Fields**
     - Adds `plant_type_id` column linking to plant_types
     - Adds `growth_stage_id` column linking to growth_stages
     - Adds `pot_size` column for tracking pot/container size
     - Adds `thumbnail_photo_id` column linking to photos for list display

  4. **User Preferences Updates**
     - Adds default plant type and growth stage preferences
     - Adds preference for showing lifecycle status fields

  5. **Indexes and RLS**
     - Proper indexes on all new foreign keys
     - RLS policies for reference tables
     - Updated RLS for photos thumbnail relationship

  ## Important Notes
  - All existing plants remain unchanged
  - New fields are optional (nullable)
  - Default data provided for common plant types and stages
  - Photo system ready for implementation in next steps
*/

-- ============================================================================
-- STEP 1: Create Plant Types Reference Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS plant_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  is_system boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_plant_types_user_name ON plant_types(user_id, name);
CREATE UNIQUE INDEX IF NOT EXISTS idx_plant_types_system_name ON plant_types(name) WHERE is_system = true;

CREATE INDEX IF NOT EXISTS idx_plant_types_user_id ON plant_types(user_id);
CREATE INDEX IF NOT EXISTS idx_plant_types_is_system ON plant_types(is_system);

-- Enable RLS
ALTER TABLE plant_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all plant types"
  ON plant_types FOR SELECT
  TO authenticated
  USING (is_system = true OR user_id = auth.uid());

CREATE POLICY "Users can insert own plant types"
  ON plant_types FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() AND is_system = false);

CREATE POLICY "Users can update own plant types"
  ON plant_types FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() AND is_system = false)
  WITH CHECK (user_id = auth.uid() AND is_system = false);

CREATE POLICY "Users can delete own plant types"
  ON plant_types FOR DELETE
  TO authenticated
  USING (user_id = auth.uid() AND is_system = false);

-- Insert default system plant types
INSERT INTO plant_types (name, description, is_system) VALUES
  ('Corm', 'Plant grown from a corm', true),
  ('Cutting', 'Plant propagated from a cutting', true),
  ('Sideshot', 'Plant grown from a side shoot or offset', true),
  ('Seedling', 'Plant grown from seed', true),
  ('Mature Plant', 'Fully established mature plant', true),
  ('Division', 'Plant created by dividing another plant', true)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- STEP 2: Create Growth Stages Reference Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS growth_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  color_code text DEFAULT '#4a7c2c',
  is_system boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_growth_stages_user_name ON growth_stages(user_id, name);
CREATE UNIQUE INDEX IF NOT EXISTS idx_growth_stages_system_name ON growth_stages(name) WHERE is_system = true;

CREATE INDEX IF NOT EXISTS idx_growth_stages_user_id ON growth_stages(user_id);
CREATE INDEX IF NOT EXISTS idx_growth_stages_is_system ON growth_stages(is_system);

-- Enable RLS
ALTER TABLE growth_stages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read all growth stages"
  ON growth_stages FOR SELECT
  TO authenticated
  USING (is_system = true OR user_id = auth.uid());

CREATE POLICY "Users can insert own growth stages"
  ON growth_stages FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid() AND is_system = false);

CREATE POLICY "Users can update own growth stages"
  ON growth_stages FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() AND is_system = false)
  WITH CHECK (user_id = auth.uid() AND is_system = false);

CREATE POLICY "Users can delete own growth stages"
  ON growth_stages FOR DELETE
  TO authenticated
  USING (user_id = auth.uid() AND is_system = false);

-- Insert default system growth stages
INSERT INTO growth_stages (name, description, color_code, is_system) VALUES
  ('Establishing', 'Recently planted or propagated, developing root system', '#9e9e9e', true),
  ('Vegetative', 'Active growth phase, producing leaves and stems', '#4caf50', true),
  ('Pre-Bloom', 'Preparing to bloom, flower buds forming', '#ff9800', true),
  ('Blooming', 'Actively flowering', '#e91e63', true),
  ('Post-Bloom', 'After flowering, seed or corm development', '#9c27b0', true),
  ('Dormant', 'Dormant period, minimal or no growth', '#795548', true)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- STEP 3: Add New Columns to Plants Table
-- ============================================================================

DO $$
BEGIN
  -- Add plant_type_id column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'plant_type_id'
  ) THEN
    ALTER TABLE plants ADD COLUMN plant_type_id uuid REFERENCES plant_types(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS idx_plants_plant_type_id ON plants(plant_type_id);
  END IF;

  -- Add growth_stage_id column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'growth_stage_id'
  ) THEN
    ALTER TABLE plants ADD COLUMN growth_stage_id uuid REFERENCES growth_stages(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS idx_plants_growth_stage_id ON plants(growth_stage_id);
  END IF;

  -- Add pot_size column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'pot_size'
  ) THEN
    ALTER TABLE plants ADD COLUMN pot_size text;
  END IF;

  -- Add thumbnail_photo_id column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'thumbnail_photo_id'
  ) THEN
    ALTER TABLE plants ADD COLUMN thumbnail_photo_id bigint REFERENCES photos(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS idx_plants_thumbnail_photo_id ON plants(thumbnail_photo_id);
  END IF;
END $$;

-- ============================================================================
-- STEP 4: Update User Preferences Table (will be applied later once table exists)
-- ============================================================================

-- Note: User preferences updates will be in a separate migration after user_preferences table is created

-- ============================================================================
-- STEP 5: Create Action Types for Status Changes
-- ============================================================================

-- Add status change action types
INSERT INTO action_types (name, requires_quantity, requires_medium, requires_nutrient, requires_cost, creates_children, child_relation_type)
VALUES
  ('Change Plant Type', false, false, false, false, false, null),
  ('Change Growth Stage', false, false, false, false, false, null),
  ('Repot', false, true, false, true, false, null)
ON CONFLICT (name) DO NOTHING;

-- ============================================================================
-- STEP 6: Create Function to Track Status Changes
-- ============================================================================

CREATE OR REPLACE FUNCTION log_plant_status_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Log plant type change
  IF OLD.plant_type_id IS DISTINCT FROM NEW.plant_type_id AND NEW.plant_type_id IS NOT NULL THEN
    INSERT INTO activity_log (
      user_id,
      plant_id,
      date,
      action_type_id,
      details,
      quantity_count,
      cost_income
    )
    SELECT
      NEW.user_id,
      NEW.id,
      CURRENT_DATE,
      (SELECT id FROM action_types WHERE name = 'Change Plant Type' LIMIT 1),
      'Plant type changed to ' || pt.name,
      0,
      0
    FROM plant_types pt
    WHERE pt.id = NEW.plant_type_id;
  END IF;

  -- Log growth stage change
  IF OLD.growth_stage_id IS DISTINCT FROM NEW.growth_stage_id AND NEW.growth_stage_id IS NOT NULL THEN
    INSERT INTO activity_log (
      user_id,
      plant_id,
      date,
      action_type_id,
      details,
      quantity_count,
      cost_income
    )
    SELECT
      NEW.user_id,
      NEW.id,
      CURRENT_DATE,
      (SELECT id FROM action_types WHERE name = 'Change Growth Stage' LIMIT 1),
      'Growth stage changed to ' || gs.name,
      0,
      0
    FROM growth_stages gs
    WHERE gs.id = NEW.growth_stage_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for status change logging
DROP TRIGGER IF EXISTS trigger_log_plant_status_change ON plants;

CREATE TRIGGER trigger_log_plant_status_change
  AFTER UPDATE ON plants
  FOR EACH ROW
  WHEN (
    OLD.plant_type_id IS DISTINCT FROM NEW.plant_type_id OR
    OLD.growth_stage_id IS DISTINCT FROM NEW.growth_stage_id
  )
  EXECUTE FUNCTION log_plant_status_change();

-- ============================================================================
-- STEP 7: Add is_thumbnail flag to photos table for faster queries
-- ============================================================================

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'photos' AND column_name = 'is_thumbnail'
  ) THEN
    ALTER TABLE photos ADD COLUMN is_thumbnail boolean DEFAULT false;
    CREATE INDEX IF NOT EXISTS idx_photos_is_thumbnail ON photos(plant_id, is_thumbnail) WHERE is_thumbnail = true;
  END IF;
END $$;

-- ============================================================================
-- STEP 8: Create Function to Update Thumbnail Flag
-- ============================================================================

CREATE OR REPLACE FUNCTION update_photo_thumbnail_flag()
RETURNS TRIGGER AS $$
BEGIN
  -- If thumbnail_photo_id changed on plant, update photo flags
  IF OLD.thumbnail_photo_id IS DISTINCT FROM NEW.thumbnail_photo_id THEN
    -- Clear old thumbnail flag
    IF OLD.thumbnail_photo_id IS NOT NULL THEN
      UPDATE photos
      SET is_thumbnail = false
      WHERE id = OLD.thumbnail_photo_id;
    END IF;

    -- Set new thumbnail flag
    IF NEW.thumbnail_photo_id IS NOT NULL THEN
      UPDATE photos
      SET is_thumbnail = true
      WHERE id = NEW.thumbnail_photo_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for thumbnail flag updates
DROP TRIGGER IF EXISTS trigger_update_photo_thumbnail_flag ON plants;

CREATE TRIGGER trigger_update_photo_thumbnail_flag
  AFTER UPDATE ON plants
  FOR EACH ROW
  WHEN (OLD.thumbnail_photo_id IS DISTINCT FROM NEW.thumbnail_photo_id)
  EXECUTE FUNCTION update_photo_thumbnail_flag();
