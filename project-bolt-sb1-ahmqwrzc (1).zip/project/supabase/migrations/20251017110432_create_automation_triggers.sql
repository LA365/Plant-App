/*
  # Create Automation Triggers and Functions

  1. Functions
    - `update_plant_from_activity()` - Updates plant fields when activity is logged
    - `update_total_corms()` - Updates total corms produced count
    - `auto_update_plant_status_on_sale()` - Updates plant status when sale is logged

  2. Triggers
    - Trigger to update last_flush_date when Flush activity is logged
    - Trigger to update last_repot_date when Repot activity is logged
    - Trigger to update total_corms_produced when Corm Harvest is logged
    - Trigger to update plant status to Sold when Sale activity is logged

  3. Important Notes
    - These triggers automatically maintain calculated fields in plants table
    - Prevents manual data entry errors
    - Ensures data consistency
*/

-- Function to update plant last_flush_date and last_repot_date from activity log
CREATE OR REPLACE FUNCTION update_plant_from_activity()
RETURNS TRIGGER AS $$
DECLARE
  action_name text;
BEGIN
  -- Get the action type name
  SELECT name INTO action_name
  FROM action_types
  WHERE id = NEW.action_type_id;

  -- Update last_flush_date if action is Flush
  IF action_name = 'Flush' THEN
    UPDATE plants
    SET last_flush_date = NEW.date::date
    WHERE id = NEW.plant_id
    AND (last_flush_date IS NULL OR NEW.date::date > last_flush_date);
  END IF;

  -- Update last_repot_date if action is Repot
  IF action_name = 'Repot' THEN
    UPDATE plants
    SET last_repot_date = NEW.date::date
    WHERE id = NEW.plant_id
    AND (last_repot_date IS NULL OR NEW.date::date > last_repot_date);
  END IF;

  -- Update total_corms_produced if action is Corm Harvest
  IF action_name = 'Corm Harvest' THEN
    UPDATE plants
    SET total_corms_produced = COALESCE(total_corms_produced, 0) + COALESCE(NEW.quantity_count, 0)
    WHERE id = NEW.plant_id;
  END IF;

  -- Update plant status to Sold if action is Sale
  IF action_name = 'Sale' THEN
    UPDATE plants
    SET status = 'Sold',
        sold_date = NEW.date::date
    WHERE id = NEW.plant_id
    AND status != 'Sold';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on activity_log INSERT
CREATE TRIGGER trigger_update_plant_from_activity
  AFTER INSERT ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION update_plant_from_activity();

-- Function to recalculate total corms when activity is updated or deleted
CREATE OR REPLACE FUNCTION recalculate_total_corms()
RETURNS TRIGGER AS $$
DECLARE
  action_name text;
  plant_id_to_update bigint;
BEGIN
  -- Determine which plant to update
  IF TG_OP = 'DELETE' THEN
    plant_id_to_update := OLD.plant_id;
    
    -- Get the action type name for OLD record
    SELECT name INTO action_name
    FROM action_types
    WHERE id = OLD.action_type_id;
  ELSE
    plant_id_to_update := NEW.plant_id;
    
    -- Get the action type name for NEW record
    SELECT name INTO action_name
    FROM action_types
    WHERE id = NEW.action_type_id;
  END IF;

  -- Only recalculate if it's a Corm Harvest action
  IF action_name = 'Corm Harvest' THEN
    UPDATE plants
    SET total_corms_produced = (
      SELECT COALESCE(SUM(al.quantity_count), 0)
      FROM activity_log al
      JOIN action_types at ON al.action_type_id = at.id
      WHERE al.plant_id = plant_id_to_update
      AND at.name = 'Corm Harvest'
    )
    WHERE id = plant_id_to_update;
  END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Trigger on activity_log UPDATE and DELETE
CREATE TRIGGER trigger_recalculate_total_corms_update
  AFTER UPDATE ON activity_log
  FOR EACH ROW
  WHEN (OLD.quantity_count IS DISTINCT FROM NEW.quantity_count OR OLD.action_type_id IS DISTINCT FROM NEW.action_type_id)
  EXECUTE FUNCTION recalculate_total_corms();

CREATE TRIGGER trigger_recalculate_total_corms_delete
  AFTER DELETE ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION recalculate_total_corms();