/*
  # Create Relationships and Photos Tables

  1. New Tables
    - `relationships` - Track plant genealogy and propagation
      - `id` (bigserial, primary key)
      - `user_id` (uuid) - Owner of the relationship
      - `child_id` (bigint) - Reference to child plant
      - `relation_type` (text) - CormFrom, CuttingFrom, PollenFather, PollenMother
      - `parent_id` (bigint) - Reference to parent plant
      - `date` (date) - Date of propagation
      - `created_at` (timestamptz)
    
    - `photos` - Store plant photos
      - `id` (bigserial, primary key)
      - `user_id` (uuid) - Owner of the photo
      - `plant_id` (bigint) - Reference to plants
      - `date` (timestamptz) - Date/time photo was taken
      - `caption` (text) - Photo caption/note
      - `image_url` (text) - URL to image in Supabase Storage
      - `local_path` (text) - Local device path for offline access
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Users can only access their own data

  3. Indexes
    - Index on user_id for both tables
    - Index on child_id and parent_id for relationships
    - Index on plant_id for photos
    - Index on date for chronological sorting
*/

-- Relationships Table
CREATE TABLE IF NOT EXISTS relationships (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  child_id bigint NOT NULL REFERENCES plants(id) ON DELETE CASCADE,
  relation_type text NOT NULL CHECK (relation_type IN ('CormFrom', 'CuttingFrom', 'PollenFather', 'PollenMother')),
  parent_id bigint NOT NULL REFERENCES plants(id) ON DELETE CASCADE,
  date date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_relationships_user_id ON relationships(user_id);
CREATE INDEX IF NOT EXISTS idx_relationships_child_id ON relationships(child_id);
CREATE INDEX IF NOT EXISTS idx_relationships_parent_id ON relationships(parent_id);

-- Enable RLS
ALTER TABLE relationships ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own relationships"
  ON relationships FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own relationships"
  ON relationships FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = relationships.child_id
      AND plants.user_id = auth.uid()
    ) AND
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = relationships.parent_id
      AND plants.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own relationships"
  ON relationships FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own relationships"
  ON relationships FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Photos Table
CREATE TABLE IF NOT EXISTS photos (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plant_id bigint NOT NULL REFERENCES plants(id) ON DELETE CASCADE,
  date timestamptz DEFAULT now(),
  caption text,
  image_url text,
  local_path text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_photos_user_id ON photos(user_id);
CREATE INDEX IF NOT EXISTS idx_photos_plant_id ON photos(plant_id);
CREATE INDEX IF NOT EXISTS idx_photos_date ON photos(date DESC);

-- Enable RLS
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own photos"
  ON photos FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own photos"
  ON photos FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = photos.plant_id
      AND plants.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own photos"
  ON photos FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own photos"
  ON photos FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Trigger to automatically update updated_at
CREATE TRIGGER update_photos_updated_at
  BEFORE UPDATE ON photos
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();