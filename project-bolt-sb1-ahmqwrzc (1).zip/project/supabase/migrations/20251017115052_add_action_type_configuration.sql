/*
  # Add Action Type Configuration

  ## Changes
  1. Add configuration columns to action_types table
    - requires_quantity: boolean for whether quantity count is required
    - requires_medium: boolean for whether medium selection is needed
    - requires_nutrient: boolean for whether nutrient selection is needed
    - requires_cost: boolean for whether cost field should be shown
    - creates_children: boolean for whether this action creates new plants
    - child_relation_type: the type of relationship created (CormFrom, CuttingFrom, SeedFrom)
  
  2. Update existing action types with appropriate configuration
*/

-- Add configuration columns to action_types
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'requires_quantity'
  ) THEN
    ALTER TABLE action_types ADD COLUMN requires_quantity BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'requires_medium'
  ) THEN
    ALTER TABLE action_types ADD COLUMN requires_medium BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'requires_nutrient'
  ) THEN
    ALTER TABLE action_types ADD COLUMN requires_nutrient BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'requires_cost'
  ) THEN
    ALTER TABLE action_types ADD COLUMN requires_cost BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'creates_children'
  ) THEN
    ALTER TABLE action_types ADD COLUMN creates_children BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'action_types' AND column_name = 'child_relation_type'
  ) THEN
    ALTER TABLE action_types ADD COLUMN child_relation_type TEXT;
    ALTER TABLE action_types ADD CONSTRAINT check_child_relation_type 
      CHECK (child_relation_type IS NULL OR child_relation_type IN ('CormFrom', 'CuttingFrom', 'SeedFrom'));
  END IF;
END $$;

-- Update existing action types with configuration
-- Flushing: only basic fields
UPDATE action_types 
SET requires_quantity = false,
    requires_medium = false,
    requires_nutrient = false,
    requires_cost = false,
    creates_children = false
WHERE name = 'Flushing';

-- Watering: can have nutrient
UPDATE action_types 
SET requires_quantity = false,
    requires_medium = false,
    requires_nutrient = true,
    requires_cost = false,
    creates_children = false
WHERE name = 'Watering';

-- Repotting: requires medium and may have cost
UPDATE action_types 
SET requires_quantity = false,
    requires_medium = true,
    requires_nutrient = false,
    requires_cost = true,
    creates_children = false
WHERE name = 'Repotting';

-- Harvesting: requires quantity and creates children
UPDATE action_types 
SET requires_quantity = true,
    requires_medium = false,
    requires_nutrient = false,
    requires_cost = false,
    creates_children = true,
    child_relation_type = 'CormFrom'
WHERE name IN ('Harvesting', 'Harvest Corms', 'Corm Harvest');

-- Fertilizing: requires nutrient and may have cost
UPDATE action_types 
SET requires_quantity = false,
    requires_medium = false,
    requires_nutrient = true,
    requires_cost = true,
    creates_children = false
WHERE name = 'Fertilizing';

-- Taking Cuttings: requires quantity and creates children
UPDATE action_types 
SET requires_quantity = true,
    requires_medium = false,
    requires_nutrient = false,
    requires_cost = false,
    creates_children = true,
    child_relation_type = 'CuttingFrom'
WHERE name IN ('Taking Cuttings', 'Propagation', 'Cuttings');

-- Seed Collection: requires quantity and creates children  
UPDATE action_types 
SET requires_quantity = true,
    requires_medium = false,
    requires_nutrient = false,
    requires_cost = false,
    creates_children = true,
    child_relation_type = 'SeedFrom'
WHERE name IN ('Seed Collection', 'Seeds', 'Seed Harvest');
