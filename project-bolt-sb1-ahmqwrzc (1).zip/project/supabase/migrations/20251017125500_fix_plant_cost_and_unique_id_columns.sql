/*
  # Fix Plant Table Schema
  
  1. Schema Changes
    - Add `purchase_cost` column (numeric) to track the cost when a plant is purchased
    - Add `propagation_cost` column (numeric) to track the cost when a plant is propagated
    - Change `unique_number` from integer to text to support alphanumeric IDs like "AMA001" or "AMA001-C1"
  
  2. Notes
    - These changes fix the plant creation error
    - The unique_number field will now support the new smart ID format
    - Cost fields are nullable to support plants without associated costs
*/

-- Add cost tracking columns
ALTER TABLE plants 
ADD COLUMN IF NOT EXISTS purchase_cost numeric DEFAULT NULL,
ADD COLUMN IF NOT EXISTS propagation_cost numeric DEFAULT NULL;

-- Change unique_number from integer to text for alphanumeric IDs
ALTER TABLE plants 
ALTER COLUMN unique_number TYPE text USING unique_number::text;

-- Add index on unique_number for faster lookups
CREATE INDEX IF NOT EXISTS idx_plants_unique_number ON plants(unique_number);

-- Add comment for documentation
COMMENT ON COLUMN plants.unique_number IS 'Smart plant ID in format like AMA001 (Alocasia Melo Albo #001) or AMA001-C1 (child from AMA001)';