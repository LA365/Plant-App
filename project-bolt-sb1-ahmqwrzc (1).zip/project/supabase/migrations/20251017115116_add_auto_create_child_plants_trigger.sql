/*
  # Auto-Create Child Plants from Activities

  ## Changes
  1. Create function to automatically create child plants when harvest/cutting/seed activities are logged
  2. Link children to parent via relationships table
  3. Set action_required flag to true for new plants
  4. Create trigger on activity_log to call this function
  
  ## How it works
  - When an activity is logged with creates_children = true and quantity_count > 0
  - Creates new plant records equal to quantity_count
  - Copies genus_id and other basic info from parent
  - Sets status to 'Active' and action_required to true
  - Links via relationships table with appropriate relation_type
*/

-- Create function to process activity and create children
CREATE OR REPLACE FUNCTION process_activity_create_children()
RETURNS TRIGGER AS $$
DECLARE
  action_config RECORD;
  parent_plant RECORD;
  new_plant_id BIGINT;
  i INTEGER;
BEGIN
  -- Get action type configuration
  SELECT * INTO action_config
  FROM action_types
  WHERE id = NEW.action_type_id;
  
  -- Only proceed if this action creates children and has quantity
  IF action_config.creates_children AND NEW.quantity_count > 0 THEN
    -- Get parent plant info
    SELECT * INTO parent_plant
    FROM plants
    WHERE id = NEW.plant_id;
    
    -- Create child plants
    FOR i IN 1..NEW.quantity_count LOOP
      INSERT INTO plants (
        user_id,
        genus_id,
        origin_type,
        propagated_date,
        status,
        action_required,
        flush_yellow_days,
        flush_red_days,
        repot_yellow_months,
        repot_red_months
      ) VALUES (
        parent_plant.user_id,
        parent_plant.genus_id,
        'Propagated',
        NEW.date::date,
        'Active',
        true,
        parent_plant.flush_yellow_days,
        parent_plant.flush_red_days,
        parent_plant.repot_yellow_months,
        parent_plant.repot_red_months
      )
      RETURNING id INTO new_plant_id;
      
      -- Create relationship record
      INSERT INTO relationships (
        user_id,
        child_id,
        parent_id,
        relation_type,
        date
      ) VALUES (
        parent_plant.user_id,
        new_plant_id,
        parent_plant.id,
        action_config.child_relation_type,
        NEW.date::date
      );
    END LOOP;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on activity_log
DROP TRIGGER IF EXISTS trigger_create_child_plants ON activity_log;
CREATE TRIGGER trigger_create_child_plants
  AFTER INSERT ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION process_activity_create_children();

-- Create function to update plant dates based on activities
CREATE OR REPLACE FUNCTION update_plant_from_activity()
RETURNS TRIGGER AS $$
DECLARE
  action_name TEXT;
BEGIN
  -- Get action type name
  SELECT name INTO action_name
  FROM action_types
  WHERE id = NEW.action_type_id;
  
  -- Update last_flush_date if this is a flushing activity
  IF action_name IN ('Flushing', 'Flush') THEN
    UPDATE plants
    SET last_flush_date = NEW.date::date
    WHERE id = NEW.plant_id;
  END IF;
  
  -- Update last_repot_date if this is a repotting activity
  IF action_name IN ('Repotting', 'Repot') THEN
    UPDATE plants
    SET last_repot_date = NEW.date::date,
        current_medium_id = COALESCE(NEW.medium_used_id, current_medium_id)
    WHERE id = NEW.plant_id;
  END IF;
  
  -- Update total_corms_produced if this is a harvest with quantity
  IF action_name IN ('Harvesting', 'Harvest Corms', 'Corm Harvest') AND NEW.quantity_count > 0 THEN
    UPDATE plants
    SET total_corms_produced = total_corms_produced + NEW.quantity_count
    WHERE id = NEW.plant_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on activity_log for updating plant data
DROP TRIGGER IF EXISTS trigger_update_plant_from_activity ON activity_log;
CREATE TRIGGER trigger_update_plant_from_activity
  AFTER INSERT ON activity_log
  FOR EACH ROW
  EXECUTE FUNCTION update_plant_from_activity();
