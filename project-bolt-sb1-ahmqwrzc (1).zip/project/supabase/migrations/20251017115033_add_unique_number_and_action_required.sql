/*
  # Add Unique Number and Action Required Fields

  ## Changes
  1. Add unique_number column to plants table
    - Integer field that auto-increments per user
    - Displayed as "P-0001" format in the app
  
  2. Add action_required flag to plants table
    - Boolean field to indicate plants needing setup
    - Default to false for existing plants
  
  3. Add function to generate next unique number for a user
  
  4. Add trigger to auto-assign unique number on plant creation
*/

-- Add unique_number column to plants table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'unique_number'
  ) THEN
    ALTER TABLE plants ADD COLUMN unique_number INTEGER;
  END IF;
END $$;

-- Add action_required column to plants table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plants' AND column_name = 'action_required'
  ) THEN
    ALTER TABLE plants ADD COLUMN action_required BOOLEAN DEFAULT false;
  END IF;
END $$;

-- Create function to get next unique number for a user
CREATE OR REPLACE FUNCTION get_next_plant_unique_number(p_user_id UUID)
RETURNS INTEGER AS $$
DECLARE
  next_number INTEGER;
BEGIN
  SELECT COALESCE(MAX(unique_number), 0) + 1
  INTO next_number
  FROM plants
  WHERE user_id = p_user_id;
  
  RETURN next_number;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function to auto-assign unique number
CREATE OR REPLACE FUNCTION assign_plant_unique_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.unique_number IS NULL THEN
    NEW.unique_number := get_next_plant_unique_number(NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on plants table
DROP TRIGGER IF EXISTS trigger_assign_plant_unique_number ON plants;
CREATE TRIGGER trigger_assign_plant_unique_number
  BEFORE INSERT ON plants
  FOR EACH ROW
  EXECUTE FUNCTION assign_plant_unique_number();

-- Assign unique numbers to existing plants (if any)
DO $$
DECLARE
  plant_record RECORD;
  user_counter INTEGER;
BEGIN
  FOR plant_record IN 
    SELECT DISTINCT user_id FROM plants WHERE unique_number IS NULL
  LOOP
    user_counter := 1;
    UPDATE plants 
    SET unique_number = user_counter
    WHERE user_id = plant_record.user_id 
      AND unique_number IS NULL
      AND id IN (
        SELECT id FROM plants 
        WHERE user_id = plant_record.user_id 
          AND unique_number IS NULL 
        ORDER BY created_at 
        LIMIT 1
      );
    
    WHILE EXISTS (SELECT 1 FROM plants WHERE user_id = plant_record.user_id AND unique_number IS NULL) LOOP
      user_counter := user_counter + 1;
      UPDATE plants 
      SET unique_number = user_counter
      WHERE user_id = plant_record.user_id 
        AND unique_number IS NULL
        AND id IN (
          SELECT id FROM plants 
          WHERE user_id = plant_record.user_id 
            AND unique_number IS NULL 
          ORDER BY created_at 
          LIMIT 1
        );
    END LOOP;
  END LOOP;
END $$;

-- Create index on unique_number for faster queries
CREATE INDEX IF NOT EXISTS idx_plants_unique_number ON plants(user_id, unique_number);
CREATE INDEX IF NOT EXISTS idx_plants_action_required ON plants(user_id, action_required) WHERE action_required = true;
