/*
  # Seed Reference Data for Plant Management

  This migration populates the reference tables with initial data needed for the app to function.

  1. Data Inserts
    - genus_options: Common plant genera (Crocus, Tulipa, Iris, etc.)
    - medium_options: Growing medium types (Sphagnum Moss, Perlite, Bark Mix, etc.)
    - nutrient_types: Fertilizer and nutrient types (Organic Liquid, Slow Release, etc.)
    - location_zones: Storage/growing locations (Greenhouse, Indoor, Outdoor, etc.)

  2. Notes
    - Uses ON CONFLICT DO NOTHING to safely re-run if needed
    - Provides sensible defaults for plant collection management
    - Users can add more options through the app later
*/

-- Insert default genus options (common bulb and plant genera)
INSERT INTO genus_options (name) VALUES
  ('Crocus'),
  ('Tulipa'),
  ('Iris'),
  ('Narcissus'),
  ('Hyacinthus'),
  ('Lilium'),
  ('Allium'),
  ('Gladiolus'),
  ('Dahlia'),
  ('Caladium'),
  ('Alocasia'),
  ('Colocasia'),
  ('Begonia'),
  ('Canna'),
  ('Cyclamen'),
  ('Anemone'),
  ('Ranunculus'),
  ('Freesia'),
  ('Muscari'),
  ('Galanthus')
ON CONFLICT (name) DO NOTHING;

-- Insert default growing medium options
INSERT INTO medium_options (name) VALUES
  ('Sphagnum Moss'),
  ('Perlite'),
  ('Bark Mix'),
  ('Potting Soil'),
  ('Coco Coir'),
  ('Peat Mix'),
  ('Sand Mix'),
  ('Vermiculite'),
  ('Leca (Clay Pebbles)'),
  ('Soil/Perlite Mix'),
  ('Custom Mix'),
  ('Hydroponic')
ON CONFLICT (name) DO NOTHING;

-- Insert default nutrient types
INSERT INTO nutrient_types (name) VALUES
  ('Organic Liquid'),
  ('Chemical Liquid'),
  ('Slow Release Granules'),
  ('Water Soluble Powder'),
  ('Fish Emulsion'),
  ('Compost Tea'),
  ('Bone Meal'),
  ('Blood Meal'),
  ('Seaweed Extract'),
  ('General Purpose 20-20-20'),
  ('Bloom Booster'),
  ('Root Stimulator'),
  ('None/Water Only')
ON CONFLICT (name) DO NOTHING;

-- Insert default location zones
INSERT INTO location_zones (name) VALUES
  ('Greenhouse - Zone 1'),
  ('Greenhouse - Zone 2'),
  ('Indoor - Shelf A'),
  ('Indoor - Shelf B'),
  ('Indoor - Windowsill'),
  ('Outdoor - Garden Bed 1'),
  ('Outdoor - Garden Bed 2'),
  ('Outdoor - Patio'),
  ('Storage - Cool'),
  ('Storage - Warm'),
  ('Propagation Area'),
  ('Quarantine')
ON CONFLICT (name) DO NOTHING;
