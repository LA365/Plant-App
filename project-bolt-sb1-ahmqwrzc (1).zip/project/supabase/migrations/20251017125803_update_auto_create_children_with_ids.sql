/*
  # Update Auto-Create Child Plants to Generate Unique IDs
  
  1. Changes
    - Update the process_activity_create_children function to generate unique IDs for child plants
    - Uses the parent plant's unique_number to generate child IDs like AMA001-C1, AMA001-C2
  
  2. Notes
    - Child plants created from activities will now automatically get properly formatted IDs
    - The ID generation follows the pattern: ParentID-C# where C stands for Child
*/

-- Create function to generate child plant ID
CREATE OR REPLACE FUNCTION generate_child_plant_id(parent_unique_number TEXT)
RETURNS TEXT AS $$
DECLARE
  child_count INTEGER;
  next_number INTEGER;
BEGIN
  -- If parent has no ID, return NULL
  IF parent_unique_number IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Count existing children with this parent prefix
  SELECT COUNT(*)
  INTO child_count
  FROM plants
  WHERE unique_number LIKE parent_unique_number || '-C%';
  
  -- Next child number
  next_number := child_count + 1;
  
  -- Return the new child ID
  RETURN parent_unique_number || '-C' || next_number;
END;
$$ LANGUAGE plpgsql;

-- Update the process_activity_create_children function to include unique_number generation
CREATE OR REPLACE FUNCTION process_activity_create_children()
RETURNS TRIGGER AS $$
DECLARE
  action_config RECORD;
  parent_plant RECORD;
  new_plant_id BIGINT;
  generated_id TEXT;
  i INTEGER;
BEGIN
  -- Get action type configuration
  SELECT * INTO action_config
  FROM action_types
  WHERE id = NEW.action_type_id;
  
  -- Only proceed if this action creates children and has quantity
  IF action_config.creates_children AND NEW.quantity_count > 0 THEN
    -- Get parent plant info
    SELECT * INTO parent_plant
    FROM plants
    WHERE id = NEW.plant_id;
    
    -- Create child plants
    FOR i IN 1..NEW.quantity_count LOOP
      -- Generate unique ID for this child
      generated_id := generate_child_plant_id(parent_plant.unique_number);
      
      INSERT INTO plants (
        user_id,
        genus_id,
        unique_number,
        origin_type,
        propagated_date,
        status,
        action_required,
        flush_yellow_days,
        flush_red_days,
        repot_yellow_months,
        repot_red_months
      ) VALUES (
        parent_plant.user_id,
        parent_plant.genus_id,
        generated_id,
        'Propagated',
        NEW.date::date,
        'Active',
        true,
        parent_plant.flush_yellow_days,
        parent_plant.flush_red_days,
        parent_plant.repot_yellow_months,
        parent_plant.repot_red_months
      )
      RETURNING id INTO new_plant_id;
      
      -- Create relationship record
      INSERT INTO relationships (
        user_id,
        child_id,
        parent_id,
        relation_type,
        date
      ) VALUES (
        parent_plant.user_id,
        new_plant_id,
        parent_plant.id,
        action_config.child_relation_type,
        NEW.date::date
      );
    END LOOP;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;