/*
  # Create Plants Master Table

  1. New Tables
    - `plants` - Master plant collection data
      - `id` (bigserial, primary key) - Auto-increment PlantID
      - `user_id` (uuid) - Owner of the plant
      - `genus_id` (uuid) - Reference to genus_options
      - `species_variety` (text) - Species/variety name
      - `origin_type` (text) - Purchased, Propagated, Cross, Gifted
      - `origin_parent_a_id` (bigint) - Reference to parent plant A
      - `origin_parent_b_id` (bigint) - Reference to parent plant B (optional)
      - `bought_date` (date) - Date purchased
      - `propagated_date` (date) - Date propagated
      - `status` (text) - Active, Sold, Dormant, Dead
      - `sold_date` (date) - Date sold
      - `current_medium_id` (uuid) - Reference to medium_options
      - `nutrient_type_id` (uuid) - Reference to nutrient_types
      - `location_zone_id` (uuid) - Reference to location_zones
      - `total_corms_produced` (integer) - Calculated field
      - `last_repot_date` (date) - Calculated from activity log
      - `last_flush_date` (date) - Calculated from activity log
      - `flush_yellow_days` (integer) - Threshold for yellow warning
      - `flush_red_days` (integer) - Threshold for red warning
      - `repot_yellow_months` (integer) - Threshold for yellow warning
      - `repot_red_months` (integer) - Threshold for red warning
      - `notes` (text) - Free-form notes
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `plant_tags` - Many-to-many relationship between plants and tags
      - `id` (uuid, primary key)
      - `plant_id` (bigint) - Reference to plants
      - `tag_id` (uuid) - Reference to tags
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on plants table
    - Users can only access their own plants
    - Enable RLS on plant_tags
    - Users can only manage tags for their own plants

  3. Indexes
    - Index on user_id for fast user queries
    - Index on genus_id for filtering by genus
    - Index on status for filtering by status
    - Index on location_zone_id for filtering by location
*/

-- Plants Table
CREATE TABLE IF NOT EXISTS plants (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  genus_id uuid REFERENCES genus_options(id),
  species_variety text,
  origin_type text CHECK (origin_type IN ('Purchased', 'Propagated', 'Cross', 'Gifted')),
  origin_parent_a_id bigint REFERENCES plants(id) ON DELETE SET NULL,
  origin_parent_b_id bigint REFERENCES plants(id) ON DELETE SET NULL,
  bought_date date,
  propagated_date date,
  status text DEFAULT 'Active' CHECK (status IN ('Active', 'Sold', 'Dormant', 'Dead')),
  sold_date date,
  current_medium_id uuid REFERENCES medium_options(id),
  nutrient_type_id uuid REFERENCES nutrient_types(id),
  location_zone_id uuid REFERENCES location_zones(id),
  total_corms_produced integer DEFAULT 0,
  last_repot_date date,
  last_flush_date date,
  flush_yellow_days integer DEFAULT 30,
  flush_red_days integer DEFAULT 60,
  repot_yellow_months integer DEFAULT 6,
  repot_red_months integer DEFAULT 12,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_plants_user_id ON plants(user_id);
CREATE INDEX IF NOT EXISTS idx_plants_genus_id ON plants(genus_id);
CREATE INDEX IF NOT EXISTS idx_plants_status ON plants(status);
CREATE INDEX IF NOT EXISTS idx_plants_location_zone_id ON plants(location_zone_id);

-- Enable RLS
ALTER TABLE plants ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own plants"
  ON plants FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own plants"
  ON plants FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own plants"
  ON plants FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own plants"
  ON plants FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Plant Tags Junction Table
CREATE TABLE IF NOT EXISTS plant_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plant_id bigint NOT NULL REFERENCES plants(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(plant_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_plant_tags_plant_id ON plant_tags(plant_id);
CREATE INDEX IF NOT EXISTS idx_plant_tags_tag_id ON plant_tags(tag_id);

ALTER TABLE plant_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own plant tags"
  ON plant_tags FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = plant_tags.plant_id
      AND plants.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own plant tags"
  ON plant_tags FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = plant_tags.plant_id
      AND plants.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own plant tags"
  ON plant_tags FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM plants
      WHERE plants.id = plant_tags.plant_id
      AND plants.user_id = auth.uid()
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at
CREATE TRIGGER update_plants_updated_at
  BEFORE UPDATE ON plants
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();