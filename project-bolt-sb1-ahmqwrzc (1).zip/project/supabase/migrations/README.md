# Database Migrations

## New Migrations to Apply

The following migrations need to be applied to your Supabase database:

### 1. `20251017120000_hierarchical_plant_numbering.sql`
**Purpose:** Implements hierarchical plant numbering system

**What it does:**
- Converts `unique_number` column from INTEGER to TEXT
- Implements hierarchical numbering (e.g., P001, P001-C001, P001-P002-S001)
- Creates functions to generate hierarchical numbers based on parent-child relationships
- Migrates existing plant numbers to the new format

**Example numbers:**
- Parent plant: `P001`
- Corm from P001: `P001-C001`
- Cutting from P001: `P001-C002`
- Seed from P001: `P001-S001`
- Seed from crossing P001 and P002: `P001-P002-S001`

### 2. `20251017120100_activity_updates_and_flush_enhancements.sql`
**Purpose:** Enhances activity management and flush date tracking

**What it does:**
- Adds 'Report' and 'Observation' action types
- Updates triggers so Report/Observation activities update the flush date
- Implements activity update/delete handling with proper recalculation
- Sets initial flush date automatically on new plants
- Ensures all plant statistics are recalculated when activities are edited or deleted

## How to Apply

These migrations are ready to be applied through your Supabase dashboard or CLI:

### Option 1: Supabase Dashboard
1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy and paste each migration file's contents
4. Run them in order (20251017120000 first, then 20251017120100)

### Option 2: Supabase CLI (if available)
```bash
supabase db push
```

## Important Notes

- Apply migrations in the order listed above
- The first migration will modify existing data (converting numbers to text format)
- All existing plant numbers will be preserved in the new format
- Activities can now be edited and deleted, with automatic recalculation of plant data
- Flush reminders now reset when logging Report or Observation activities
