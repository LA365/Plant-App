import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Platform,
} from 'react-native';
import { Calendar } from 'lucide-react-native';

interface DatePickerProps {
  label: string;
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
}

export function DatePicker({
  label,
  value,
  onValueChange,
  placeholder = 'Select date',
}: DatePickerProps) {
  const [modalVisible, setModalVisible] = useState(false);
  const [tempDate, setTempDate] = useState(value || getTodayString());

  const displayText = value || placeholder;

  function getTodayString() {
    const today = new Date();
    return today.toISOString().split('T')[0];
  }

  function formatDateForDisplay(dateString: string) {
    if (!dateString) return placeholder;
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  function handleConfirm() {
    onValueChange(tempDate);
    setModalVisible(false);
  }

  function handleClear() {
    onValueChange('');
    setModalVisible(false);
  }

  function adjustDate(days: number) {
    const date = new Date(tempDate + 'T00:00:00');
    date.setDate(date.getDate() + days);
    setTempDate(date.toISOString().split('T')[0]);
  }

  function adjustMonth(months: number) {
    const date = new Date(tempDate + 'T00:00:00');
    date.setMonth(date.getMonth() + months);
    setTempDate(date.toISOString().split('T')[0]);
  }

  function adjustYear(years: number) {
    const date = new Date(tempDate + 'T00:00:00');
    date.setFullYear(date.getFullYear() + years);
    setTempDate(date.toISOString().split('T')[0]);
  }

  function setToToday() {
    setTempDate(getTodayString());
  }

  return (
    <>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity
        style={styles.dateButton}
        onPress={() => {
          setTempDate(value || getTodayString());
          setModalVisible(true);
        }}
      >
        <Text style={[styles.dateText, !value && styles.placeholder]}>
          {value ? formatDateForDisplay(value) : placeholder}
        </Text>
        <Calendar size={20} color="#999" />
      </TouchableOpacity>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{label}</Text>

            <View style={styles.dateDisplay}>
              <Text style={styles.dateDisplayText}>
                {formatDateForDisplay(tempDate)}
              </Text>
            </View>

            <View style={styles.adjustmentSection}>
              <Text style={styles.adjustmentLabel}>Day</Text>
              <View style={styles.adjustmentButtons}>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustDate(-1)}
                >
                  <Text style={styles.adjustButtonText}>-1</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustDate(1)}
                >
                  <Text style={styles.adjustButtonText}>+1</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.adjustmentSection}>
              <Text style={styles.adjustmentLabel}>Month</Text>
              <View style={styles.adjustmentButtons}>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustMonth(-1)}
                >
                  <Text style={styles.adjustButtonText}>-1</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustMonth(1)}
                >
                  <Text style={styles.adjustButtonText}>+1</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.adjustmentSection}>
              <Text style={styles.adjustmentLabel}>Year</Text>
              <View style={styles.adjustmentButtons}>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustYear(-1)}
                >
                  <Text style={styles.adjustButtonText}>-1</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.adjustButton}
                  onPress={() => adjustYear(1)}
                >
                  <Text style={styles.adjustButtonText}>+1</Text>
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity style={styles.todayButton} onPress={setToToday}>
              <Text style={styles.todayButtonText}>Today</Text>
            </TouchableOpacity>

            <View style={styles.buttonRow}>
              <TouchableOpacity
                style={[styles.actionButton, styles.clearButton]}
                onPress={handleClear}
              >
                <Text style={styles.clearButtonText}>Clear</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.confirmButton]}
                onPress={handleConfirm}
              >
                <Text style={styles.confirmButtonText}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
    marginTop: 12,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
  },
  dateText: {
    fontSize: 16,
    color: '#333',
  },
  placeholder: {
    color: '#999',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    width: '85%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  dateDisplay: {
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
  },
  dateDisplayText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#4a7c2c',
    textAlign: 'center',
  },
  adjustmentSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  adjustmentLabel: {
    fontSize: 16,
    color: '#666',
    flex: 1,
  },
  adjustmentButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  adjustButton: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 6,
    minWidth: 60,
  },
  adjustButtonText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    fontWeight: '500',
  },
  todayButton: {
    backgroundColor: '#e8f5e9',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
    marginBottom: 20,
  },
  todayButtonText: {
    fontSize: 16,
    color: '#4a7c2c',
    textAlign: 'center',
    fontWeight: '600',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  clearButton: {
    backgroundColor: '#ffebee',
  },
  clearButtonText: {
    fontSize: 16,
    color: '#d32f2f',
    fontWeight: '600',
  },
  cancelButton: {
    backgroundColor: '#f0f0f0',
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  confirmButton: {
    backgroundColor: '#4a7c2c',
  },
  confirmButtonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
});
