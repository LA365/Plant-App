import { supabase } from '@/lib/supabase';

export interface IdConfig {
  separator: string;
  digitCount: number;
}

export const DEFAULT_ID_CONFIG: IdConfig = {
  separator: '-',
  digitCount: 1,
};

export const getInitials = (text: string | null): string => {
  if (!text) return '';

  const words = text.trim().split(/\s+/);
  return words
    .map(word => word.charAt(0).toUpperCase())
    .join('');
};

export const padNumber = (num: number, config: IdConfig = DEFAULT_ID_CONFIG): string => {
  return num.toString();
};

export const parseBaseId = (uniqueNumber: string, config: IdConfig = DEFAULT_ID_CONFIG): {
  baseId: string;
  hasChild: boolean;
} => {
  const parts = uniqueNumber.split(config.separator);
  const baseId = parts[0];
  const hasChild = parts.length > 1;

  return { baseId, hasChild };
};

export const generateBaseId = async (
  genusName: string,
  speciesVariety: string | null,
  config: IdConfig = DEFAULT_ID_CONFIG
): Promise<string> => {
  const genusInitial = genusName.charAt(0).toUpperCase();
  const speciesInitials = getInitials(speciesVariety);

  let prefix = genusInitial + speciesInitials;

  const { data: existingPlants, error } = await supabase
    .from('plants')
    .select('unique_number')
    .not('unique_number', 'is', null);

  if (error) {
    console.error('Error fetching existing plant IDs:', error);
    return `${prefix}${padNumber(1, config)}`;
  }

  const existingIds = (existingPlants || [])
    .map(p => p.unique_number)
    .filter(id => id !== null) as string[];

  const sameGenusSpecies = existingIds.filter(id => {
    const parsed = parseBaseId(id, config);
    return parsed.baseId.startsWith(prefix);
  });

  if (sameGenusSpecies.length > 0) {
    const conflictingBaseId = sameGenusSpecies.some(id => {
      const parsed = parseBaseId(id, config);
      const basePrefix = parsed.baseId.replace(/\d+$/, '');
      return basePrefix === prefix;
    });

    if (conflictingBaseId) {
      prefix = genusName.substring(0, 2).toUpperCase() + speciesInitials;
    }
  }

  const existingNumbers = sameGenusSpecies
    .map(id => {
      const parsed = parseBaseId(id, config);
      const match = parsed.baseId.match(/(\d+)$/);
      return match ? parseInt(match[1], 10) : 0;
    })
    .filter(num => num > 0);

  const nextNumber = existingNumbers.length > 0
    ? Math.max(...existingNumbers) + 1
    : 1;

  return `${prefix}${padNumber(nextNumber, config)}`;
};

export const generateChildId = async (
  parentUniqueNumber: string,
  config: IdConfig = DEFAULT_ID_CONFIG
): Promise<string> => {
  const { data: siblings, error } = await supabase
    .from('plants')
    .select('unique_number')
    .not('unique_number', 'is', null)
    .like('unique_number', `${parentUniqueNumber}${config.separator}%`);

  if (error) {
    console.error('Error fetching sibling plants:', error);
    return `${parentUniqueNumber}${config.separator}1`;
  }

  const siblingIds = (siblings || [])
    .map(p => p.unique_number)
    .filter(id => id !== null) as string[];

  const childNumbers = siblingIds
    .map(id => {
      const parts = id.split(config.separator);
      if (parts.length >= 2 && parts[0] === parentUniqueNumber) {
        const lastPart = parts[parts.length - 1];
        const numMatch = lastPart.match(/^\d+/);
        return numMatch ? parseInt(numMatch[0], 10) : 0;
      }
      return 0;
    })
    .filter(num => num > 0);

  const nextNumber = childNumbers.length > 0
    ? Math.max(...childNumbers) + 1
    : 1;

  return `${parentUniqueNumber}${config.separator}${nextNumber}`;
};

export const generateCrossId = async (
  parent1UniqueNumber: string,
  parent2UniqueNumber: string,
  config: IdConfig = DEFAULT_ID_CONFIG
): Promise<string> => {
  const searchPattern = `${parent1UniqueNumber}${config.separator}${parent2UniqueNumber}${config.separator}%`;

  const { data: siblings, error } = await supabase
    .from('plants')
    .select('unique_number')
    .not('unique_number', 'is', null)
    .like('unique_number', searchPattern);

  if (error) {
    console.error('Error fetching cross siblings:', error);
    return `${parent1UniqueNumber}${config.separator}${parent2UniqueNumber}${config.separator}1`;
  }

  const siblingIds = (siblings || [])
    .map(p => p.unique_number)
    .filter(id => id !== null) as string[];

  const crossNumbers = siblingIds
    .map(id => {
      const parts = id.split(config.separator);
      if (parts.length >= 3) {
        const lastPart = parts[parts.length - 1];
        const numMatch = lastPart.match(/^\d+/);
        return numMatch ? parseInt(numMatch[0], 10) : 0;
      }
      return 0;
    })
    .filter(num => num > 0);

  const nextNumber = crossNumbers.length > 0
    ? Math.max(...crossNumbers) + 1
    : 1;

  return `${parent1UniqueNumber}${config.separator}${parent2UniqueNumber}${config.separator}${nextNumber}`;
};

export const generatePlantId = async (
  genusName: string,
  speciesVariety: string | null,
  originType: 'Purchased' | 'Propagated' | 'Cross' | 'Gifted',
  parentAUniqueNumber?: string | null,
  parentBUniqueNumber?: string | null,
  config: IdConfig = DEFAULT_ID_CONFIG
): Promise<string> => {
  if (originType === 'Cross' && parentAUniqueNumber && parentBUniqueNumber) {
    return generateCrossId(parentAUniqueNumber, parentBUniqueNumber, config);
  }

  if (originType === 'Propagated' && parentAUniqueNumber) {
    return generateChildId(parentAUniqueNumber, config);
  }

  return generateBaseId(genusName, speciesVariety, config);
};
