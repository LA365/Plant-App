import { Plant, FlushStatus, RepotStatus } from '@/types/database';

export function calculateDaysSince(date: string | null): number | null {
  if (!date) return null;
  const targetDate = new Date(date);
  const today = new Date();
  const diffTime = Math.abs(today.getTime() - targetDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

export function calculateMonthsSince(date: string | null): number | null {
  if (!date) return null;
  const targetDate = new Date(date);
  const today = new Date();

  let months = (today.getFullYear() - targetDate.getFullYear()) * 12;
  months -= targetDate.getMonth();
  months += today.getMonth();

  return months <= 0 ? 0 : months;
}

export function getFlushStatus(plant: Plant): FlushStatus {
  const daysSince = calculateDaysSince(plant.last_flush_date);

  if (daysSince === null) return 'red';
  if (daysSince >= plant.flush_red_days) return 'red';
  if (daysSince >= plant.flush_yellow_days) return 'yellow';
  return 'green';
}

export function getRepotStatus(plant: Plant): RepotStatus {
  const monthsSince = calculateMonthsSince(plant.last_repot_date);

  if (monthsSince === null) return 'red';
  if (monthsSince >= plant.repot_red_months) return 'red';
  if (monthsSince >= plant.repot_yellow_months) return 'yellow';
  return 'green';
}

export function getStatusColor(status: FlushStatus | RepotStatus): string {
  switch (status) {
    case 'green':
      return '#4caf50';
    case 'yellow':
      return '#ff9800';
    case 'red':
      return '#f44336';
    default:
      return '#999';
  }
}

export function getPlantDisplayName(plant: Plant, genus?: { name: string }): string {
  const uniqueId = plant.unique_number;
  const genusName = genus?.name || 'Unknown';
  const species = plant.species_variety || '';
  const plantName = species ? `${genusName} ${species}` : genusName;

  if (uniqueId) {
    return `${uniqueId} • ${plantName}`;
  }

  return `Plant #${plant.id} • ${plantName}`;
}

export function formatUniqueNumber(uniqueNumber: string | null): string {
  if (uniqueNumber) {
    return uniqueNumber;
  }
  return 'No ID';
}
