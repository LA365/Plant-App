import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  ActionType,
  PlantWithRelations,
  MediumOption,
  NutrientType,
} from '@/types/database';
import { Picker } from '@/components/Picker';
import { DatePicker } from '@/components/DatePicker';
import { getPlantDisplayName } from '@/utils/plantStatus';

export default function ActivityFormScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const activityId = params.id ? parseInt(params.id as string) : null;
  const preselectedPlantId = params.plantId ? parseInt(params.plantId as string) : null;
  const isEditing = activityId !== null;

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [plants, setPlants] = useState<PlantWithRelations[]>([]);
  const [actionTypes, setActionTypes] = useState<ActionType[]>([]);
  const [selectedActionType, setSelectedActionType] = useState<ActionType | null>(null);
  const [mediumList, setMediumList] = useState<MediumOption[]>([]);
  const [nutrientList, setNutrientList] = useState<NutrientType[]>([]);

  const [formData, setFormData] = useState({
    plant_id: preselectedPlantId?.toString() || '',
    date: new Date().toISOString().split('T')[0],
    action_type_id: '',
    details: '',
    medium_used_id: '',
    nutrient_type_id: '',
    quantity_count: '0',
    cost_income: '0',
  });

  useEffect(() => {
    loadReferenceData();
    if (isEditing) {
      loadActivity();
    }
  }, []);

  const loadReferenceData = async () => {
    try {
      const [plantsRes, actionTypesRes, mediumRes, nutrientRes] = await Promise.all([
        supabase
          .from('plants')
          .select('*, genus:genus_id(id, name)')
          .eq('status', 'Active')
          .order('created_at', { ascending: false }),
        supabase.from('action_types').select('*').order('name'),
        supabase.from('medium_options').select('*').order('name'),
        supabase.from('nutrient_types').select('*').order('name'),
      ]);

      if (plantsRes.data) setPlants(plantsRes.data);
      if (actionTypesRes.data) {
        setActionTypes(actionTypesRes.data);
        if (formData.action_type_id) {
          const selected = actionTypesRes.data.find(at => at.id === formData.action_type_id);
          setSelectedActionType(selected || null);
        }
      }
      if (mediumRes.data) setMediumList(mediumRes.data);
      if (nutrientRes.data) setNutrientList(nutrientRes.data);
    } catch (err) {
      console.error('Error loading reference data:', err);
    }
  };

  const loadActivity = async () => {
    try {
      const { data, error } = await supabase
        .from('activity_log')
        .select('*')
        .eq('id', activityId)
        .single();

      if (error) throw error;

      if (data) {
        setFormData({
          plant_id: data.plant_id.toString(),
          date: data.date,
          action_type_id: data.action_type_id || '',
          details: data.details || '',
          medium_used_id: data.medium_used_id || '',
          nutrient_type_id: data.nutrient_type_id || '',
          quantity_count: data.quantity_count.toString(),
          cost_income: data.cost_income.toString(),
        });
      }
    } catch (err) {
      console.error('Error loading activity:', err);
      setError('Failed to load activity data');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.plant_id || !formData.action_type_id) {
      setError('Please select a plant and action type');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const activityData = {
        user_id: user?.id,
        plant_id: parseInt(formData.plant_id),
        date: formData.date,
        action_type_id: formData.action_type_id || null,
        details: formData.details || null,
        medium_used_id: formData.medium_used_id || null,
        nutrient_type_id: formData.nutrient_type_id || null,
        quantity_count: parseInt(formData.quantity_count) || 0,
        cost_income: parseFloat(formData.cost_income) || 0,
        photo_link: null,
      };

      if (isEditing) {
        const { error } = await supabase
          .from('activity_log')
          .update(activityData)
          .eq('id', activityId);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('activity_log').insert(activityData);

        if (error) throw error;
      }

      router.back();
    } catch (err: any) {
      console.error('Error saving activity:', err);
      setError(err.message || 'Failed to save activity');
    } finally {
      setSaving(false);
    }
  };

  const plantOptions = plants.map((plant) => ({
    id: plant.id.toString(),
    name: getPlantDisplayName(plant, plant.genus),
  }));

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {isEditing ? 'Edit Activity' : 'Log Activity'}
        </Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={saving}
          style={styles.saveButton}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#4a7c2c" />
          ) : (
            <Text style={styles.saveButtonText}>Save</Text>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Activity Details</Text>

          <Picker
            label="Plant"
            value={formData.plant_id}
            options={plantOptions}
            onValueChange={(value) => setFormData({ ...formData, plant_id: value })}
            placeholder="Select plant"
            required
          />

          <DatePicker
            label="Date"
            value={formData.date}
            onValueChange={(value) => setFormData({ ...formData, date: value })}
          />

          <Picker
            label="Action Type"
            value={formData.action_type_id}
            options={actionTypes}
            onValueChange={(value) => {
              const selected = actionTypes.find(at => at.id === value);
              setSelectedActionType(selected || null);
              setFormData({ ...formData, action_type_id: value });
            }}
            placeholder="Select action type"
            required
          />

          <Text style={styles.label}>Details</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={formData.details}
            onChangeText={(text) => setFormData({ ...formData, details: text })}
            placeholder="Add notes about this activity..."
            placeholderTextColor="#999"
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>

        {(selectedActionType?.requires_medium || selectedActionType?.requires_nutrient) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Materials Used</Text>

            {selectedActionType?.requires_medium && (
              <Picker
                label="Growing Medium"
                value={formData.medium_used_id}
                options={mediumList}
                onValueChange={(value) => setFormData({ ...formData, medium_used_id: value })}
                placeholder="Select medium (optional)"
              />
            )}

            {selectedActionType?.requires_nutrient && (
              <Picker
                label="Nutrient Type"
                value={formData.nutrient_type_id}
                options={nutrientList}
                onValueChange={(value) => setFormData({ ...formData, nutrient_type_id: value })}
                placeholder="Select nutrient (optional)"
              />
            )}
          </View>
        )}

        {(selectedActionType?.requires_quantity || selectedActionType?.requires_cost) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Quantities & Costs</Text>

            {selectedActionType?.requires_quantity && (
              <>
                <Text style={styles.label}>
                  Quantity Count {selectedActionType?.creates_children && <Text style={styles.required}>*</Text>}
                </Text>
                <TextInput
                  style={styles.input}
                  value={formData.quantity_count}
                  onChangeText={(text) => setFormData({ ...formData, quantity_count: text })}
                  keyboardType="numeric"
                  placeholder="0"
                  placeholderTextColor="#999"
                />
                <Text style={styles.helpText}>
                  {selectedActionType?.creates_children
                    ? `Will create ${formData.quantity_count || 0} new plant(s)`
                    : 'e.g., number of corms harvested, cuttings taken, etc.'}
                </Text>
              </>
            )}

            {selectedActionType?.requires_cost && (
              <>
                <Text style={styles.label}>Cost / Income (DKK)</Text>
                <TextInput
                  style={styles.input}
                  value={formData.cost_income}
                  onChangeText={(text) => setFormData({ ...formData, cost_income: text })}
                  keyboardType="decimal-pad"
                  placeholder="0.00"
                  placeholderTextColor="#999"
                />
                <Text style={styles.helpText}>
                  Positive for income, negative for expenses
                </Text>
              </>
            )}
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  saveButton: {
    minWidth: 60,
    alignItems: 'flex-end',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    padding: 16,
    backgroundColor: '#ffebee',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
  },
  section: {
    backgroundColor: '#fff',
    padding: 16,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d5016',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
    marginTop: 12,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    minHeight: 100,
    paddingTop: 12,
  },
  helpText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  required: {
    color: '#d32f2f',
  },
});
