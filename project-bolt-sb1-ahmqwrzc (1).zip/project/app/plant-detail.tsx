import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import {
  X,
  Edit,
  Trash2,
  Circle,
  Calendar,
  MapPin,
  Droplet,
  FlaskConical,
  Check,
  AlertCircle,
  MoreVertical,
  DollarSign,
  TrendingUp,
  Users,
  Camera,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { PlantWithRelations, ActivityLogWithRelations } from '@/types/database';
import { getFlushStatus, getRepotStatus, getStatusColor, getPlantDisplayName, formatUniqueNumber } from '@/utils/plantStatus';

export default function PlantDetailScreen() {
  const params = useLocalSearchParams();
  const plantId = params.id ? parseInt(params.id as string) : null;

  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [plant, setPlant] = useState<PlantWithRelations | null>(null);
  const [activities, setActivities] = useState<ActivityLogWithRelations[]>([]);
  const [completingSetup, setCompletingSetup] = useState(false);
  const [parentPlant, setParentPlant] = useState<PlantWithRelations | null>(null);
  const [childrenPlants, setChildrenPlants] = useState<PlantWithRelations[]>([]);
  const [profitability, setProfitability] = useState<{
    total_cost: number;
    total_income: number;
    net_profit: number;
    roi_percentage: number;
  } | null>(null);

  const loadPlantData = useCallback(async () => {
    try {
      const [plantRes, activitiesRes, relationshipsRes, profitRes] = await Promise.all([
        supabase
          .from('plants')
          .select(`
            *,
            genus:genus_id(id, name),
            current_medium:current_medium_id(id, name),
            nutrient_type:nutrient_type_id(id, name),
            location_zone:location_zone_id(id, name)
          `)
          .eq('id', plantId)
          .single(),
        supabase
          .from('activity_log')
          .select(`
            *,
            action_type:action_type_id(id, name)
          `)
          .eq('plant_id', plantId)
          .order('date', { ascending: false })
          .limit(10),
        supabase
          .from('relationships')
          .select('*')
          .or(`child_id.eq.${plantId},parent_id.eq.${plantId}`),
        supabase.rpc('calculate_plant_profitability', { p_plant_id: plantId }),
      ]);

      if (plantRes.error) throw plantRes.error;
      if (plantRes.data) {
        setPlant(plantRes.data);

        if (relationshipsRes.data) {
          const parentRel = relationshipsRes.data.find(r => r.child_id === plantId);
          if (parentRel) {
            const { data: parentData } = await supabase
              .from('plants')
              .select('*, genus:genus_id(id, name)')
              .eq('id', parentRel.parent_id)
              .single();
            if (parentData) setParentPlant(parentData);
          }

          const childRels = relationshipsRes.data.filter(r => r.parent_id === plantId);
          if (childRels.length > 0) {
            const childIds = childRels.map(r => r.child_id);
            const { data: childrenData } = await supabase
              .from('plants')
              .select('*, genus:genus_id(id, name)')
              .in('id', childIds);
            if (childrenData) setChildrenPlants(childrenData);
          }
        }
      }
      if (activitiesRes.data) setActivities(activitiesRes.data);
      if (profitRes.data && profitRes.data.length > 0) {
        setProfitability(profitRes.data[0]);
      }
    } catch (error) {
      console.error('Error loading plant:', error);
      Alert.alert('Error', 'Failed to load plant data');
    } finally {
      setLoading(false);
    }
  }, [plantId]);

  useEffect(() => {
    if (plantId) {
      loadPlantData();
    }
  }, [plantId, loadPlantData]);

  const handleCompleteSetup = async () => {
    setCompletingSetup(true);
    try {
      const { error } = await supabase
        .from('plants')
        .update({ action_required: false })
        .eq('id', plantId);

      if (error) throw error;

      router.push(`/plant-form?id=${plantId}`);
    } catch (error) {
      console.error('Error completing setup:', error);
      Alert.alert('Error', 'Failed to update plant');
    } finally {
      setCompletingSetup(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Plant',
      'Are you sure you want to delete this plant? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setDeleting(true);
            try {
              const { error } = await supabase
                .from('plants')
                .delete()
                .eq('id', plantId);

              if (error) throw error;
              router.back();
            } catch (error) {
              console.error('Error deleting plant:', error);
              Alert.alert('Error', 'Failed to delete plant');
            } finally {
              setDeleting(false);
            }
          },
        },
      ]
    );
  };

  const handleDeleteActivity = (activityId: number) => {
    Alert.alert(
      'Delete Activity',
      'Are you sure you want to delete this activity? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('activity_log')
                .delete()
                .eq('id', activityId);

              if (error) throw error;
              loadPlantData();
            } catch (error) {
              console.error('Error deleting activity:', error);
              Alert.alert('Error', 'Failed to delete activity');
            }
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  if (!plant) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.errorText}>Plant not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const flushStatus = getFlushStatus(plant);
  const repotStatus = getRepotStatus(plant);
  const displayName = getPlantDisplayName(plant, plant.genus);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Plant Details</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            onPress={() => router.push(`/plant-form?id=${plantId}`)}
            style={styles.iconButton}
          >
            <Edit size={20} color="#4a7c2c" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={handleDelete}
            disabled={deleting}
            style={styles.iconButton}
          >
            {deleting ? (
              <ActivityIndicator size="small" color="#d32f2f" />
            ) : (
              <Trash2 size={20} color="#d32f2f" />
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {plant.action_required && (
          <View style={styles.setupAlert}>
            <AlertCircle size={24} color="#ff9800" />
            <View style={styles.setupAlertContent}>
              <Text style={styles.setupAlertTitle}>Setup Required</Text>
              <Text style={styles.setupAlertText}>
                Complete medium and location setup for this plant
              </Text>
            </View>
            <TouchableOpacity
              style={styles.setupButton}
              onPress={handleCompleteSetup}
              disabled={completingSetup}
            >
              {completingSetup ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Check size={20} color="#fff" />
              )}
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.mainCard}>
          <View style={styles.plantHeader}>
            <View style={styles.plantTitleRow}>
              <Text style={styles.plantName}>{displayName}</Text>
              <View
                style={[
                  styles.statusBadge,
                  { backgroundColor: plant.status === 'Active' ? '#e8f5e9' : '#f0f0f0' },
                ]}
              >
                <Text
                  style={[
                    styles.statusText,
                    { color: plant.status === 'Active' ? '#4a7c2c' : '#999' },
                  ]}
                >
                  {plant.status}
                </Text>
              </View>
            </View>

            <View style={styles.statusRow}>
              <View style={styles.statusItem}>
                <Circle size={12} color={getStatusColor(flushStatus)} fill={getStatusColor(flushStatus)} />
                <Text style={styles.statusLabel}>Flush</Text>
              </View>
              <View style={styles.statusItem}>
                <Circle size={12} color={getStatusColor(repotStatus)} fill={getStatusColor(repotStatus)} />
                <Text style={styles.statusLabel}>Repot</Text>
              </View>
            </View>
          </View>

          <View style={styles.infoGrid}>
            {plant.location_zone && (
              <View style={styles.infoItem}>
                <MapPin size={18} color="#666" />
                <Text style={styles.infoLabel}>Location</Text>
                <Text style={styles.infoValue}>{plant.location_zone.name}</Text>
              </View>
            )}

            {plant.current_medium && (
              <View style={styles.infoItem}>
                <Droplet size={18} color="#666" />
                <Text style={styles.infoLabel}>Medium</Text>
                <Text style={styles.infoValue}>{plant.current_medium.name}</Text>
              </View>
            )}

            {plant.nutrient_type && (
              <View style={styles.infoItem}>
                <FlaskConical size={18} color="#666" />
                <Text style={styles.infoLabel}>Nutrients</Text>
                <Text style={styles.infoValue}>{plant.nutrient_type.name}</Text>
              </View>
            )}

            <View style={styles.infoItem}>
              <Calendar size={18} color="#666" />
              <Text style={styles.infoLabel}>Origin</Text>
              <Text style={styles.infoValue}>
                {plant.origin_type}
                {plant.bought_date && ` - ${formatDate(plant.bought_date)}`}
                {plant.propagated_date && ` - ${formatDate(plant.propagated_date)}`}
              </Text>
            </View>
          </View>

          {(plant.purchase_cost || plant.propagation_cost || profitability) && (
            <View style={styles.profitabilitySection}>
              <View style={styles.profitabilityHeader}>
                <DollarSign size={20} color="#4a7c2c" />
                <Text style={styles.profitabilityTitle}>Profitability</Text>
              </View>
              <View style={styles.profitabilityGrid}>
                {(plant.purchase_cost || plant.propagation_cost) && (
                  <View style={styles.profitItem}>
                    <Text style={styles.profitLabel}>Cost</Text>
                    <Text style={styles.profitValue}>
                      {((plant.purchase_cost || 0) + (plant.propagation_cost || 0)).toFixed(2)} DKK
                    </Text>
                  </View>
                )}
                {profitability && (
                  <>
                    <View style={styles.profitItem}>
                      <Text style={styles.profitLabel}>Income</Text>
                      <Text style={[styles.profitValue, { color: '#4caf50' }]}>
                        {profitability.total_income.toFixed(2)} DKK
                      </Text>
                    </View>
                    <View style={styles.profitItem}>
                      <Text style={styles.profitLabel}>Net Profit</Text>
                      <Text
                        style={[
                          styles.profitValue,
                          { color: profitability.net_profit >= 0 ? '#4caf50' : '#f44336' }
                        ]}
                      >
                        {profitability.net_profit >= 0 ? '+' : ''}{profitability.net_profit.toFixed(2)} DKK
                      </Text>
                    </View>
                    <View style={styles.profitItem}>
                      <Text style={styles.profitLabel}>ROI</Text>
                      <Text
                        style={[
                          styles.profitValue,
                          { color: profitability.roi_percentage >= 0 ? '#4caf50' : '#f44336' }
                        ]}
                      >
                        {profitability.roi_percentage.toFixed(1)}%
                      </Text>
                    </View>
                  </>
                )}
              </View>
            </View>
          )}

          {plant.total_corms_produced > 0 && (
            <View style={styles.statsRow}>
              <Text style={styles.statsLabel}>Total Corms Produced:</Text>
              <Text style={styles.statsValue}>{plant.total_corms_produced}</Text>
            </View>
          )}

          {plant.notes && (
            <View style={styles.notesSection}>
              <Text style={styles.notesLabel}>Notes</Text>
              <Text style={styles.notesText}>{plant.notes}</Text>
            </View>
          )}
        </View>

        {(parentPlant || childrenPlants.length > 0) && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Users size={20} color="#4a7c2c" />
              <Text style={styles.sectionTitle}>Heritage</Text>
            </View>

            {parentPlant && (
              <View style={styles.heritageCard}>
                <Text style={styles.heritageLabel}>Parent Plant</Text>
                <TouchableOpacity
                  onPress={() => router.push(`/plant-detail?id=${parentPlant.id}`)}
                  style={styles.heritagePlantButton}
                >
                  <Text style={styles.heritagePlantName}>
                    {getPlantDisplayName(parentPlant, parentPlant.genus)}
                  </Text>
                  <Text style={styles.heritagePlantArrow}>→</Text>
                </TouchableOpacity>
              </View>
            )}

            {childrenPlants.length > 0 && (
              <View style={styles.heritageCard}>
                <Text style={styles.heritageLabel}>
                  Children ({childrenPlants.length})
                </Text>
                {childrenPlants.map((child) => (
                  <TouchableOpacity
                    key={child.id}
                    onPress={() => router.push(`/plant-detail?id=${child.id}`)}
                    style={styles.heritagePlantButton}
                  >
                    <Text style={styles.heritagePlantName}>
                      {getPlantDisplayName(child, child.genus)}
                    </Text>
                    <Text style={styles.heritagePlantArrow}>→</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderLeft}>
              <Camera size={20} color="#4a7c2c" />
              <Text style={styles.sectionTitle}>Photos</Text>
            </View>
            <TouchableOpacity
              onPress={() => router.push(`/plant-photos?plantId=${plantId}`)}
            >
              <Text style={styles.sectionAction}>View All</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={styles.addPhotoCard}
            onPress={() => router.push(`/plant-photos?plantId=${plantId}`)}
          >
            <Camera size={32} color="#4a7c2c" />
            <Text style={styles.addPhotoText}>Add Photos</Text>
            <Text style={styles.addPhotoSubtext}>Track your plant's growth</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <TouchableOpacity
              onPress={() => router.push(`/activity-form?plantId=${plantId}`)}
            >
              <Text style={styles.sectionAction}>Add</Text>
            </TouchableOpacity>
          </View>

          {activities.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>No activities logged yet</Text>
            </View>
          ) : (
            activities.map((activity) => (
              <View key={activity.id} style={styles.activityCard}>
                <View style={styles.activityHeader}>
                  <Text style={styles.activityType}>{activity.action_type?.name}</Text>
                  <View style={styles.activityActions}>
                    <TouchableOpacity
                      onPress={() => router.push(`/activity-form?id=${activity.id}`)}
                      style={styles.activityActionButton}
                    >
                      <Edit size={16} color="#4a7c2c" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleDeleteActivity(activity.id)}
                      style={styles.activityActionButton}
                    >
                      <Trash2 size={16} color="#d32f2f" />
                    </TouchableOpacity>
                  </View>
                </View>
                <Text style={styles.activityDate}>{formatDate(activity.date)}</Text>
                {activity.details && (
                  <Text style={styles.activityDetails}>{activity.details}</Text>
                )}
                {activity.quantity_count > 0 && (
                  <Text style={styles.activityMeta}>Qty: {activity.quantity_count}</Text>
                )}
              </View>
            ))
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  iconButton: {
    padding: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#999',
  },
  content: {
    flex: 1,
  },
  mainCard: {
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  plantHeader: {
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    paddingBottom: 16,
    marginBottom: 16,
  },
  plantTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  plantName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2d5016',
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  statusRow: {
    flexDirection: 'row',
    gap: 16,
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
  },
  infoGrid: {
    gap: 12,
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    minWidth: 80,
  },
  infoValue: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#e8f5e9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  statsLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#2d5016',
  },
  statsValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4a7c2c',
  },
  notesSection: {
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 4,
  },
  notesText: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  sectionAction: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  addPhotoCard: {
    backgroundColor: '#fff',
    padding: 32,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  addPhotoText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
    marginTop: 12,
  },
  addPhotoSubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 4,
  },
  emptyState: {
    backgroundColor: '#fff',
    padding: 32,
    borderRadius: 12,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
  },
  activityCard: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  activityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  activityType: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4a7c2c',
    flex: 1,
  },
  activityActions: {
    flexDirection: 'row',
    gap: 8,
  },
  activityActionButton: {
    padding: 4,
  },
  activityDate: {
    fontSize: 12,
    color: '#999',
    marginBottom: 4,
  },
  activityDetails: {
    fontSize: 13,
    color: '#666',
    marginBottom: 4,
  },
  activityMeta: {
    fontSize: 12,
    color: '#999',
  },
  setupAlert: {
    backgroundColor: '#fff3e0',
    borderLeftWidth: 4,
    borderLeftColor: '#ff9800',
    marginHorizontal: 16,
    marginTop: 16,
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  setupAlertContent: {
    flex: 1,
  },
  setupAlertTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#e65100',
    marginBottom: 4,
  },
  setupAlertText: {
    fontSize: 14,
    color: '#ef6c00',
  },
  setupButton: {
    backgroundColor: '#ff9800',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profitabilitySection: {
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
    marginTop: 12,
  },
  profitabilityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  profitabilityTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2d5016',
  },
  profitabilityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  profitItem: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  profitLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  profitValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  heritageCard: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  heritageLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
  },
  heritagePlantButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: '#f9f9f9',
    borderRadius: 6,
    marginBottom: 6,
  },
  heritagePlantName: {
    fontSize: 14,
    color: '#4a7c2c',
    fontWeight: '500',
    flex: 1,
  },
  heritagePlantArrow: {
    fontSize: 16,
    color: '#4a7c2c',
  },
});
