import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { X, CheckSquare } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  ActionType,
  PlantWithRelations,
  MediumOption,
  NutrientType,
  LocationZone,
} from '@/types/database';
import { Picker } from '@/components/Picker';
import { DatePicker } from '@/components/DatePicker';
import { getPlantDisplayName } from '@/utils/plantStatus';

export default function BulkActivityScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const plantIds = params.plantIds ? JSON.parse(params.plantIds as string) : [];

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [plants, setPlants] = useState<PlantWithRelations[]>([]);
  const [actionTypes, setActionTypes] = useState<ActionType[]>([]);
  const [selectedActionType, setSelectedActionType] = useState<ActionType | null>(null);
  const [mediumList, setMediumList] = useState<MediumOption[]>([]);
  const [nutrientList, setNutrientList] = useState<NutrientType[]>([]);
  const [locationList, setLocationList] = useState<LocationZone[]>([]);

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    action_type_id: '',
    details: '',
    medium_used_id: '',
    nutrient_type_id: '',
    location_zone_id: '',
    quantity_count: '0',
    cost_income: '0',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [plantsRes, actionTypesRes, mediumRes, nutrientRes, locationRes] = await Promise.all([
        supabase
          .from('plants')
          .select('*, genus:genus_id(id, name)')
          .in('id', plantIds),
        supabase.from('action_types').select('*').order('name'),
        supabase.from('medium_options').select('*').order('name'),
        supabase.from('nutrient_types').select('*').order('name'),
        supabase.from('location_zones').select('*').order('name'),
      ]);

      if (plantsRes.data) setPlants(plantsRes.data);
      if (actionTypesRes.data) {
        setActionTypes(actionTypesRes.data);
      }
      if (mediumRes.data) setMediumList(mediumRes.data);
      if (nutrientRes.data) setNutrientList(nutrientRes.data);
      if (locationRes.data) setLocationList(locationRes.data);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.action_type_id) {
      setError('Please select an action type');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const activities = plants.map((plant) => ({
        user_id: user?.id,
        plant_id: plant.id,
        date: formData.date,
        action_type_id: formData.action_type_id || null,
        details: formData.details || null,
        medium_used_id: formData.medium_used_id || null,
        nutrient_type_id: formData.nutrient_type_id || null,
        quantity_count: parseInt(formData.quantity_count) || 0,
        cost_income: parseFloat(formData.cost_income) || 0,
        photo_link: null,
      }));

      const { error } = await supabase.from('activity_log').insert(activities);

      if (error) throw error;

      if (formData.location_zone_id) {
        const { error: updateError } = await supabase
          .from('plants')
          .update({ location_zone_id: formData.location_zone_id })
          .in('id', plantIds);

        if (updateError) throw updateError;
      }

      Alert.alert(
        'Success',
        `Activity logged for ${plants.length} plant${plants.length > 1 ? 's' : ''}`,
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (err: any) {
      console.error('Error saving bulk activity:', err);
      setError(err.message || 'Failed to save activities');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Bulk Action</Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={saving}
          style={styles.saveButton}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#4a7c2c" />
          ) : (
            <Text style={styles.saveButtonText}>Save</Text>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.section}>
          <View style={styles.selectionHeader}>
            <CheckSquare size={20} color="#4a7c2c" />
            <Text style={styles.selectionText}>
              {plants.length} Plant{plants.length > 1 ? 's' : ''} Selected
            </Text>
          </View>
          <View style={styles.plantsList}>
            {plants.map((plant) => (
              <View key={plant.id} style={styles.plantChip}>
                <Text style={styles.plantChipText}>
                  {getPlantDisplayName(plant, plant.genus)}
                </Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Activity Details</Text>

          <DatePicker
            label="Date"
            value={formData.date}
            onValueChange={(value) => setFormData({ ...formData, date: value })}
          />

          <Picker
            label="Action Type"
            value={formData.action_type_id}
            options={actionTypes}
            onValueChange={(value) => {
              const selected = actionTypes.find(at => at.id === value);
              setSelectedActionType(selected || null);
              setFormData({ ...formData, action_type_id: value });
            }}
            placeholder="Select action type"
            required
          />

          <Text style={styles.label}>Details</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={formData.details}
            onChangeText={(text) => setFormData({ ...formData, details: text })}
            placeholder="Add notes about this activity..."
            placeholderTextColor="#999"
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>

        {selectedActionType?.requires_medium && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Medium</Text>
            <Picker
              label="Growing Medium"
              value={formData.medium_used_id}
              options={mediumList}
              onValueChange={(value) => setFormData({ ...formData, medium_used_id: value })}
              placeholder="Select medium (optional)"
            />
          </View>
        )}

        {selectedActionType?.requires_nutrient && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Nutrients</Text>
            <Picker
              label="Nutrient Type"
              value={formData.nutrient_type_id}
              options={nutrientList}
              onValueChange={(value) => setFormData({ ...formData, nutrient_type_id: value })}
              placeholder="Select nutrient (optional)"
            />
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Bulk Operations</Text>

          <Picker
            label="Move to Location (optional)"
            value={formData.location_zone_id}
            options={locationList}
            onValueChange={(value) => setFormData({ ...formData, location_zone_id: value })}
            placeholder="Keep current locations"
          />
          <Text style={styles.helpText}>
            If selected, all plants will be moved to this location
          </Text>
        </View>

        {selectedActionType?.requires_quantity && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Quantity</Text>
            <Text style={styles.label}>Quantity Count</Text>
            <TextInput
              style={styles.input}
              value={formData.quantity_count}
              onChangeText={(text) => setFormData({ ...formData, quantity_count: text })}
              keyboardType="numeric"
              placeholder="0"
              placeholderTextColor="#999"
            />
            <Text style={styles.helpText}>
              Applied to each plant individually
            </Text>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  saveButton: {
    minWidth: 60,
    alignItems: 'flex-end',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    padding: 16,
    backgroundColor: '#ffebee',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
  },
  section: {
    backgroundColor: '#fff',
    padding: 16,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  selectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  selectionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  plantsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  plantChip: {
    backgroundColor: '#e8f5e9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  plantChipText: {
    fontSize: 13,
    color: '#2d5016',
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d5016',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
    marginTop: 12,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    minHeight: 100,
    paddingTop: 12,
  },
  helpText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
});
