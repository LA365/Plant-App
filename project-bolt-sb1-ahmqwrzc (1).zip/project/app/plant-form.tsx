import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  GenusOption,
  MediumOption,
  NutrientType,
  LocationZone,
  Plant,
  PlantType,
  GrowthStage,
} from '@/types/database';
import { Picker } from '@/components/Picker';
import { DatePicker } from '@/components/DatePicker';
import { generatePlantId } from '@/utils/plantIdGenerator';

export default function PlantFormScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const plantId = params.id ? parseInt(params.id as string) : null;
  const isEditing = plantId !== null;

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [generatedId, setGeneratedId] = useState<string>('');
  const [parentPlants, setParentPlants] = useState<Plant[]>([]);
  const [parentAId, setParentAId] = useState<number | null>(null);
  const [parentBId, setParentBId] = useState<number | null>(null);

  const [genusList, setGenusList] = useState<GenusOption[]>([]);
  const [mediumList, setMediumList] = useState<MediumOption[]>([]);
  const [nutrientList, setNutrientList] = useState<NutrientType[]>([]);
  const [locationList, setLocationList] = useState<LocationZone[]>([]);
  const [plantTypeList, setPlantTypeList] = useState<PlantType[]>([]);
  const [growthStageList, setGrowthStageList] = useState<GrowthStage[]>([]);
  const [tagList, setTagList] = useState<{ id: string; name: string }[]>([]);
  const [selectedTags, setSelectedTags] = useState<Set<string>>(new Set());

  const [formData, setFormData] = useState({
    genus_id: '',
    species_variety: '',
    plant_type_id: '',
    growth_stage_id: '',
    pot_size: '',
    origin_type: 'Purchased' as 'Purchased' | 'Propagated' | 'Cross' | 'Gifted',
    bought_date: '',
    propagated_date: '',
    purchase_cost: '',
    propagation_cost: '',
    status: 'Active' as 'Active' | 'Sold' | 'Dormant' | 'Dead',
    sold_date: '',
    current_medium_id: '',
    nutrient_type_id: '',
    location_zone_id: '',
    flush_yellow_days: '30',
    flush_red_days: '60',
    repot_yellow_months: '6',
    repot_red_months: '12',
    notes: '',
  });

  useEffect(() => {
    loadReferenceData();
    loadParentPlants();
    if (isEditing) {
      loadPlant();
    }
  }, []);

  useEffect(() => {
    if (!isEditing) {
      generateIdPreview();
    }
  }, [formData.genus_id, formData.species_variety, formData.origin_type, parentAId, parentBId]);

  const loadReferenceData = async () => {
    try {
      const [genusRes, mediumRes, nutrientRes, locationRes, plantTypeRes, growthStageRes, tagsRes] = await Promise.all([
        supabase.from('genus_options').select('*').order('name'),
        supabase.from('medium_options').select('*').order('name'),
        supabase.from('nutrient_types').select('*').order('name'),
        supabase.from('location_zones').select('*').order('name'),
        supabase.from('plant_types').select('*').order('name'),
        supabase.from('growth_stages').select('*').order('name'),
        supabase.from('tags').select('*').order('name'),
      ]);

      if (genusRes.data) setGenusList(genusRes.data);
      if (mediumRes.data) setMediumList(mediumRes.data);
      if (nutrientRes.data) setNutrientList(nutrientRes.data);
      if (locationRes.data) setLocationList(locationRes.data);
      if (plantTypeRes.data) setPlantTypeList(plantTypeRes.data);
      if (growthStageRes.data) setGrowthStageList(growthStageRes.data);
      if (tagsRes.data) setTagList(tagsRes.data);
    } catch (err) {
      console.error('Error loading reference data:', err);
    }
  };

  const loadParentPlants = async () => {
    try {
      const { data, error } = await supabase
        .from('plants')
        .select('id, unique_number, genus_id, species_variety')
        .eq('status', 'Active')
        .not('unique_number', 'is', null)
        .order('unique_number');

      if (error) throw error;
      if (data) setParentPlants(data as Plant[]);
    } catch (err) {
      console.error('Error loading parent plants:', err);
    }
  };

  const generateIdPreview = async () => {
    if (!formData.genus_id) {
      setGeneratedId('');
      return;
    }

    const selectedGenus = genusList.find(g => g.id === formData.genus_id);
    if (!selectedGenus) return;

    try {
      const parentAPlant = parentPlants.find(p => p.id === parentAId);
      const parentBPlant = parentPlants.find(p => p.id === parentBId);

      const id = await generatePlantId(
        selectedGenus.name,
        formData.species_variety || null,
        formData.origin_type,
        parentAPlant?.unique_number,
        parentBPlant?.unique_number
      );

      setGeneratedId(id);
    } catch (err) {
      console.error('Error generating ID preview:', err);
      setGeneratedId('Error generating ID');
    }
  };

  const loadPlant = async () => {
    try {
      const [plantRes, plantTagsRes] = await Promise.all([
        supabase
          .from('plants')
          .select('*')
          .eq('id', plantId)
          .single(),
        supabase
          .from('plant_tags')
          .select('tag_id')
          .eq('plant_id', plantId),
      ]);

      if (plantRes.error) throw plantRes.error;

      if (plantRes.data) {
        setFormData({
          genus_id: plantRes.data.genus_id || '',
          species_variety: plantRes.data.species_variety || '',
          plant_type_id: plantRes.data.plant_type_id || '',
          growth_stage_id: plantRes.data.growth_stage_id || '',
          pot_size: plantRes.data.pot_size || '',
          origin_type: plantRes.data.origin_type || 'Purchased',
          bought_date: plantRes.data.bought_date || '',
          propagated_date: plantRes.data.propagated_date || '',
          purchase_cost: plantRes.data.purchase_cost ? plantRes.data.purchase_cost.toString() : '',
          propagation_cost: plantRes.data.propagation_cost ? plantRes.data.propagation_cost.toString() : '',
          status: plantRes.data.status,
          sold_date: plantRes.data.sold_date || '',
          current_medium_id: plantRes.data.current_medium_id || '',
          nutrient_type_id: plantRes.data.nutrient_type_id || '',
          location_zone_id: plantRes.data.location_zone_id || '',
          flush_yellow_days: plantRes.data.flush_yellow_days.toString(),
          flush_red_days: plantRes.data.flush_red_days.toString(),
          repot_yellow_months: plantRes.data.repot_yellow_months.toString(),
          repot_red_months: plantRes.data.repot_red_months.toString(),
          notes: plantRes.data.notes || '',
        });
      }

      if (plantTagsRes.data) {
        const tagIds = new Set(plantTagsRes.data.map(pt => pt.tag_id));
        setSelectedTags(tagIds);
      }
    } catch (err) {
      console.error('Error loading plant:', err);
      setError('Failed to load plant data');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.genus_id) {
      setError('Please select a genus');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const plantData: any = {
        user_id: user?.id,
        genus_id: formData.genus_id || null,
        species_variety: formData.species_variety || null,
        plant_type_id: formData.plant_type_id || null,
        growth_stage_id: formData.growth_stage_id || null,
        pot_size: formData.pot_size || null,
        origin_type: formData.origin_type,
        bought_date: formData.bought_date || null,
        propagated_date: formData.propagated_date || null,
        purchase_cost: formData.purchase_cost ? parseFloat(formData.purchase_cost) : null,
        propagation_cost: formData.propagation_cost ? parseFloat(formData.propagation_cost) : null,
        status: formData.status,
        sold_date: formData.status === 'Sold' ? formData.sold_date || null : null,
        current_medium_id: formData.current_medium_id || null,
        nutrient_type_id: formData.nutrient_type_id || null,
        location_zone_id: formData.location_zone_id || null,
        flush_yellow_days: parseInt(formData.flush_yellow_days) || 30,
        flush_red_days: parseInt(formData.flush_red_days) || 60,
        repot_yellow_months: parseInt(formData.repot_yellow_months) || 6,
        repot_red_months: parseInt(formData.repot_red_months) || 12,
        notes: formData.notes || null,
      };

      if (!isEditing && generatedId) {
        plantData.unique_number = generatedId;
      }

      if (formData.origin_type === 'Propagated' && parentAId) {
        plantData.origin_parent_a_id = parentAId;
      }

      if (formData.origin_type === 'Cross' && parentAId && parentBId) {
        plantData.origin_parent_a_id = parentAId;
        plantData.origin_parent_b_id = parentBId;
      }

      let savedPlantId = plantId;

      if (isEditing) {
        const { error } = await supabase
          .from('plants')
          .update(plantData)
          .eq('id', plantId);

        if (error) throw error;

        await supabase.from('plant_tags').delete().eq('plant_id', plantId);
      } else {
        const { data: newPlant, error } = await supabase
          .from('plants')
          .insert(plantData)
          .select()
          .single();

        if (error) throw error;
        if (newPlant) savedPlantId = newPlant.id;
      }

      if (selectedTags.size > 0 && savedPlantId) {
        const tagInserts = Array.from(selectedTags).map(tagId => ({
          plant_id: savedPlantId,
          tag_id: tagId,
        }));

        const { error: tagError } = await supabase
          .from('plant_tags')
          .insert(tagInserts);

        if (tagError) throw tagError;
      }

      router.back();
    } catch (err: any) {
      console.error('Error saving plant:', err);
      setError(err.message || 'Failed to save plant');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{isEditing ? 'Edit Plant' : 'Add Plant'}</Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={saving}
          style={styles.saveButton}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#4a7c2c" />
          ) : (
            <Text style={styles.saveButtonText}>Save</Text>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Basic Information</Text>

          <Picker
            label="Genus"
            value={formData.genus_id}
            options={genusList}
            onValueChange={(value) => setFormData({ ...formData, genus_id: value })}
            placeholder="Select genus"
            required
          />

          <Text style={styles.label}>Species / Variety</Text>
          <TextInput
            style={styles.input}
            value={formData.species_variety}
            onChangeText={(text) => setFormData({ ...formData, species_variety: text })}
            placeholder="e.g., 'Melo Albo'"
            placeholderTextColor="#999"
          />

          <Picker
            label="Plant Type"
            value={formData.plant_type_id}
            options={plantTypeList}
            onValueChange={(value) => setFormData({ ...formData, plant_type_id: value })}
            placeholder="Select plant type"
          />

          <Picker
            label="Growth Stage"
            value={formData.growth_stage_id}
            options={growthStageList}
            onValueChange={(value) => setFormData({ ...formData, growth_stage_id: value })}
            placeholder="Select growth stage"
          />

          {!isEditing && generatedId && (
            <View style={styles.idPreview}>
              <Text style={styles.idPreviewLabel}>Plant ID:</Text>
              <Text style={styles.idPreviewValue}>{generatedId}</Text>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Origin</Text>

          <Picker
            label="Origin Type"
            value={formData.origin_type}
            options={[
              { id: 'Purchased', name: 'Purchased' },
              { id: 'Propagated', name: 'Propagated' },
              { id: 'Cross', name: 'Cross' },
              { id: 'Gifted', name: 'Gifted' },
            ]}
            onValueChange={(value) =>
              setFormData({ ...formData, origin_type: value as any })
            }
            placeholder="Select origin type"
          />

          {formData.origin_type === 'Purchased' && (
            <>
              <DatePicker
                label="Bought Date"
                value={formData.bought_date}
                onValueChange={(value) => setFormData({ ...formData, bought_date: value })}
                placeholder="Select date"
              />
              <Text style={styles.label}>Purchase Cost (DKK)</Text>
              <TextInput
                style={styles.input}
                value={formData.purchase_cost}
                onChangeText={(text) => setFormData({ ...formData, purchase_cost: text })}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor="#999"
              />
            </>
          )}

          {formData.origin_type === 'Propagated' && (
            <>
              <Picker
                label="Parent Plant"
                value={parentAId?.toString() || ''}
                options={parentPlants.map(p => ({
                  id: p.id.toString(),
                  name: `${p.unique_number} - ${p.species_variety || 'Unknown'}`
                }))}
                onValueChange={(value) => setParentAId(value ? parseInt(value) : null)}
                placeholder="Select parent plant"
              />
              <DatePicker
                label="Propagated Date"
                value={formData.propagated_date}
                onValueChange={(value) => setFormData({ ...formData, propagated_date: value })}
                placeholder="Select date"
              />
              <Text style={styles.label}>Propagation Cost (DKK)</Text>
              <TextInput
                style={styles.input}
                value={formData.propagation_cost}
                onChangeText={(text) => setFormData({ ...formData, propagation_cost: text })}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor="#999"
              />
              <Text style={styles.helpText}>Optional: Material costs for propagation</Text>
            </>
          )}

          {formData.origin_type === 'Cross' && (
            <>
              <Picker
                label="Parent Plant A"
                value={parentAId?.toString() || ''}
                options={parentPlants.map(p => ({
                  id: p.id.toString(),
                  name: `${p.unique_number} - ${p.species_variety || 'Unknown'}`
                }))}
                onValueChange={(value) => setParentAId(value ? parseInt(value) : null)}
                placeholder="Select first parent"
              />
              <Picker
                label="Parent Plant B"
                value={parentBId?.toString() || ''}
                options={parentPlants.map(p => ({
                  id: p.id.toString(),
                  name: `${p.unique_number} - ${p.species_variety || 'Unknown'}`
                }))}
                onValueChange={(value) => setParentBId(value ? parseInt(value) : null)}
                placeholder="Select second parent"
              />
              <DatePicker
                label="Propagated Date"
                value={formData.propagated_date}
                onValueChange={(value) => setFormData({ ...formData, propagated_date: value })}
                placeholder="Select date"
              />
              <Text style={styles.label}>Propagation Cost (DKK)</Text>
              <TextInput
                style={styles.input}
                value={formData.propagation_cost}
                onChangeText={(text) => setFormData({ ...formData, propagation_cost: text })}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor="#999"
              />
              <Text style={styles.helpText}>Optional: Material costs for breeding</Text>
            </>
          )}

          {formData.origin_type === 'Gifted' && (
            <DatePicker
              label="Received Date"
              value={formData.bought_date}
              onValueChange={(value) => setFormData({ ...formData, bought_date: value })}
              placeholder="Select date"
            />
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Status</Text>

          <Picker
            label="Status"
            value={formData.status}
            options={[
              { id: 'Active', name: 'Active' },
              { id: 'Sold', name: 'Sold' },
              { id: 'Dormant', name: 'Dormant' },
              { id: 'Dead', name: 'Dead' },
            ]}
            onValueChange={(value) => setFormData({ ...formData, status: value as any })}
            placeholder="Select status"
          />

          {formData.status === 'Sold' && (
            <DatePicker
              label="Sold Date"
              value={formData.sold_date}
              onValueChange={(value) => setFormData({ ...formData, sold_date: value })}
              placeholder="Select date"
            />
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>

          <Picker
            label="Location / Zone"
            value={formData.location_zone_id}
            options={locationList}
            onValueChange={(value) => setFormData({ ...formData, location_zone_id: value })}
            placeholder="Select location"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Care Settings</Text>

          <Picker
            label="Growing Medium"
            value={formData.current_medium_id}
            options={mediumList}
            onValueChange={(value) => setFormData({ ...formData, current_medium_id: value })}
            placeholder="Select medium"
          />

          <Picker
            label="Nutrient Type"
            value={formData.nutrient_type_id}
            options={nutrientList}
            onValueChange={(value) => setFormData({ ...formData, nutrient_type_id: value })}
            placeholder="Select nutrient"
          />

          <Text style={styles.label}>Pot Size</Text>
          <TextInput
            style={styles.input}
            value={formData.pot_size}
            onChangeText={(text) => setFormData({ ...formData, pot_size: text })}
            placeholder="e.g., '15cm' or '6 inch'"
            placeholderTextColor="#999"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Maintenance Thresholds</Text>

          <View style={styles.row}>
            <View style={styles.halfWidth}>
              <Text style={styles.label}>Flush Warning (days)</Text>
              <TextInput
                style={styles.input}
                value={formData.flush_yellow_days}
                onChangeText={(text) =>
                  setFormData({ ...formData, flush_yellow_days: text })
                }
                keyboardType="numeric"
                placeholder="30"
                placeholderTextColor="#999"
              />
            </View>
            <View style={styles.halfWidth}>
              <Text style={styles.label}>Flush Alert (days)</Text>
              <TextInput
                style={styles.input}
                value={formData.flush_red_days}
                onChangeText={(text) => setFormData({ ...formData, flush_red_days: text })}
                keyboardType="numeric"
                placeholder="60"
                placeholderTextColor="#999"
              />
            </View>
          </View>

          <View style={styles.row}>
            <View style={styles.halfWidth}>
              <Text style={styles.label}>Repot Warning (months)</Text>
              <TextInput
                style={styles.input}
                value={formData.repot_yellow_months}
                onChangeText={(text) =>
                  setFormData({ ...formData, repot_yellow_months: text })
                }
                keyboardType="numeric"
                placeholder="6"
                placeholderTextColor="#999"
              />
            </View>
            <View style={styles.halfWidth}>
              <Text style={styles.label}>Repot Alert (months)</Text>
              <TextInput
                style={styles.input}
                value={formData.repot_red_months}
                onChangeText={(text) =>
                  setFormData({ ...formData, repot_red_months: text })
                }
                keyboardType="numeric"
                placeholder="12"
                placeholderTextColor="#999"
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tags</Text>
          {tagList.length === 0 ? (
            <Text style={styles.helpText}>No tags available. Create tags in Reference Data.</Text>
          ) : (
            <View style={styles.tagsContainer}>
              {tagList.map((tag) => {
                const isSelected = selectedTags.has(tag.id);
                return (
                  <TouchableOpacity
                    key={tag.id}
                    style={[styles.tagChip, isSelected && styles.tagChipSelected]}
                    onPress={() => {
                      const newTags = new Set(selectedTags);
                      if (isSelected) {
                        newTags.delete(tag.id);
                      } else {
                        newTags.add(tag.id);
                      }
                      setSelectedTags(newTags);
                    }}
                  >
                    <Text style={[styles.tagChipText, isSelected && styles.tagChipTextSelected]}>
                      {tag.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notes</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={formData.notes}
            onChangeText={(text) => setFormData({ ...formData, notes: text })}
            placeholder="Add any notes about this plant..."
            placeholderTextColor="#999"
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  saveButton: {
    minWidth: 60,
    alignItems: 'flex-end',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    padding: 16,
    backgroundColor: '#ffebee',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
  },
  section: {
    backgroundColor: '#fff',
    padding: 16,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d5016',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
    marginTop: 12,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    minHeight: 100,
    paddingTop: 12,
  },
  helpText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  idPreview: {
    backgroundColor: '#e8f5e9',
    borderLeftWidth: 4,
    borderLeftColor: '#4a7c2c',
    padding: 16,
    borderRadius: 8,
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  idPreviewLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#2d5016',
  },
  idPreviewValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4a7c2c',
    letterSpacing: 1,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tagChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  tagChipSelected: {
    backgroundColor: '#4a7c2c',
    borderColor: '#4a7c2c',
  },
  tagChipText: {
    fontSize: 14,
    color: '#666',
  },
  tagChipTextSelected: {
    color: '#fff',
    fontWeight: '500',
  },
});
