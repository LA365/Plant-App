import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Alert,
  Dimensions,
  TextInput,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { X, Trash2, Star, Edit, Check } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Photo } from '@/types/database';
import { PhotoPicker } from '@/components/PhotoPicker';

const { width } = Dimensions.get('window');
const photoSize = (width - 48) / 3;

export default function PlantPhotosScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const plantId = params.plantId ? parseInt(params.plantId as string) : null;

  const [loading, setLoading] = useState(true);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [plantName, setPlantName] = useState('');
  const [editingPhoto, setEditingPhoto] = useState<Photo | null>(null);
  const [editCaption, setEditCaption] = useState('');

  useEffect(() => {
    if (plantId) {
      loadPhotos();
      loadPlantName();
    }
  }, [plantId]);

  const loadPlantName = async () => {
    try {
      const { data, error } = await supabase
        .from('plants')
        .select('genus_id, species_variety, genus:genus_id(name)')
        .eq('id', plantId)
        .single();

      if (error) throw error;
      if (data) {
        const genusName = (data.genus as any)?.name || 'Unknown';
        setPlantName(`${genusName}${data.species_variety ? ' ' + data.species_variety : ''}`);
      }
    } catch (error) {
      console.error('Error loading plant name:', error);
    }
  };

  const loadPhotos = async () => {
    try {
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('plant_id', plantId)
        .order('date', { ascending: false });

      if (error) throw error;
      setPhotos(data || []);
    } catch (error) {
      console.error('Error loading photos:', error);
      Alert.alert('Error', 'Failed to load photos');
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUploaded = () => {
    loadPhotos();
  };

  const handleSetThumbnail = async (photoId: number) => {
    try {
      await supabase
        .from('photos')
        .update({ is_thumbnail: false })
        .eq('plant_id', plantId);

      const { error } = await supabase
        .from('photos')
        .update({ is_thumbnail: true })
        .eq('id', photoId);

      if (error) throw error;

      const { error: plantError } = await supabase
        .from('plants')
        .update({ thumbnail_photo_id: photoId })
        .eq('id', plantId);

      if (plantError) throw plantError;

      loadPhotos();
      Alert.alert('Success', 'Thumbnail updated');
    } catch (error) {
      console.error('Error setting thumbnail:', error);
      Alert.alert('Error', 'Failed to set thumbnail');
    }
  };

  const handleDeletePhoto = (photoId: number, imageUrl: string | null) => {
    Alert.alert(
      'Delete Photo',
      'Are you sure you want to delete this photo?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              if (imageUrl) {
                const path = imageUrl.split('/plant-photos/')[1];
                if (path) {
                  await supabase.storage.from('plant-photos').remove([path]);
                }
              }

              const { error } = await supabase
                .from('photos')
                .delete()
                .eq('id', photoId);

              if (error) throw error;
              loadPhotos();
            } catch (error) {
              console.error('Error deleting photo:', error);
              Alert.alert('Error', 'Failed to delete photo');
            }
          },
        },
      ]
    );
  };

  const handleEditCaption = (photo: Photo) => {
    setEditingPhoto(photo);
    setEditCaption(photo.caption || '');
  };

  const handleSaveCaption = async () => {
    if (!editingPhoto) return;

    try {
      const { error } = await supabase
        .from('photos')
        .update({ caption: editCaption || null })
        .eq('id', editingPhoto.id);

      if (error) throw error;

      setEditingPhoto(null);
      setEditCaption('');
      loadPhotos();
      Alert.alert('Success', 'Caption updated');
    } catch (error) {
      console.error('Error updating caption:', error);
      Alert.alert('Error', 'Failed to update caption');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Photos</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {plantName && (
          <Text style={styles.plantName}>{plantName}</Text>
        )}

        <View style={styles.section}>
          <PhotoPicker
            plantId={plantId || undefined}
            userId={user?.id}
            onPhotoSelected={handlePhotoUploaded}
            label="Add New Photo"
          />
        </View>

        {photos.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>No photos yet</Text>
            <Text style={styles.emptySubtext}>Add photos to track your plant's growth</Text>
          </View>
        ) : (
          <View style={styles.photoGrid}>
            {photos.map((photo) => (
              <View key={photo.id} style={styles.photoCard}>
                <Image
                  source={{ uri: photo.image_url || photo.local_path || '' }}
                  style={styles.photoImage}
                />
                {photo.is_thumbnail && (
                  <View style={styles.thumbnailBadge}>
                    <Star size={12} color="#fff" fill="#fff" />
                  </View>
                )}
                <View style={styles.photoActions}>
                  <TouchableOpacity
                    style={styles.actionButton}
                    onPress={() => handleSetThumbnail(photo.id)}
                  >
                    <Star
                      size={16}
                      color={photo.is_thumbnail ? '#ffd700' : '#fff'}
                      fill={photo.is_thumbnail ? '#ffd700' : 'none'}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.actionButton}
                    onPress={() => handleEditCaption(photo)}
                  >
                    <Edit size={16} color="#fff" />
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.actionButton}
                    onPress={() => handleDeletePhoto(photo.id, photo.image_url)}
                  >
                    <Trash2 size={16} color="#fff" />
                  </TouchableOpacity>
                </View>
                <View style={styles.photoInfo}>
                  <Text style={styles.photoDate}>{formatDate(photo.date)}</Text>
                  {photo.caption ? (
                    <Text style={styles.photoCaption} numberOfLines={2}>
                      {photo.caption}
                    </Text>
                  ) : (
                    <Text style={styles.photoCaptionPlaceholder}>Tap edit to add caption</Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>

      <Modal
        visible={editingPhoto !== null}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setEditingPhoto(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Caption</Text>
              <TouchableOpacity onPress={() => setEditingPhoto(null)}>
                <X size={24} color="#333" />
              </TouchableOpacity>
            </View>

            {editingPhoto && (
              <Image
                source={{ uri: editingPhoto.image_url || editingPhoto.local_path || '' }}
                style={styles.modalImage}
              />
            )}

            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Caption</Text>
              <TextInput
                style={styles.captionInput}
                value={editCaption}
                onChangeText={setEditCaption}
                placeholder="Add a caption for this photo..."
                placeholderTextColor="#999"
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>

            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setEditingPhoto(null)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSaveCaption}>
                <Check size={20} color="#fff" />
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  plantName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2d5016',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  section: {
    backgroundColor: '#fff',
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 12,
    gap: 8,
  },
  photoCard: {
    width: photoSize,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  photoImage: {
    width: '100%',
    height: photoSize,
    backgroundColor: '#f0f0f0',
  },
  thumbnailBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#ffd700',
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoActions: {
    position: 'absolute',
    top: 8,
    left: 8,
    flexDirection: 'row',
    gap: 4,
  },
  actionButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    borderRadius: 12,
    width: 28,
    height: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoInfo: {
    padding: 8,
  },
  photoDate: {
    fontSize: 11,
    color: '#999',
    marginBottom: 2,
  },
  photoCaption: {
    fontSize: 12,
    color: '#666',
  },
  photoCaptionPlaceholder: {
    fontSize: 11,
    color: '#999',
    fontStyle: 'italic',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 20,
    width: '90%',
    maxWidth: 500,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  modalImage: {
    width: '100%',
    height: 200,
    backgroundColor: '#f0f0f0',
  },
  modalBody: {
    padding: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
  },
  captionInput: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
    minHeight: 80,
  },
  modalFooter: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  saveButton: {
    flex: 1,
    flexDirection: 'row',
    paddingVertical: 14,
    borderRadius: 8,
    backgroundColor: '#4a7c2c',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
});
