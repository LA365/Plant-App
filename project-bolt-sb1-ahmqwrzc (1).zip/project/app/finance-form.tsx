import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { X } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  FinanceCategory,
  PlantWithRelations,
} from '@/types/database';
import { Picker } from '@/components/Picker';
import { DatePicker } from '@/components/DatePicker';
import { getPlantDisplayName } from '@/utils/plantStatus';

export default function FinanceFormScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const financeId = params.id ? parseInt(params.id as string) : null;
  const isEditing = financeId !== null;

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [plants, setPlants] = useState<PlantWithRelations[]>([]);
  const [categories, setCategories] = useState<FinanceCategory[]>([]);

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    type: 'Expense' as 'Income' | 'Expense',
    category_id: '',
    description: '',
    amount: '',
    related_plant_id: '',
    payment_method: '',
  });

  useEffect(() => {
    loadReferenceData();
    if (isEditing) {
      loadFinance();
    }
  }, []);

  const loadReferenceData = async () => {
    try {
      const [plantsRes, categoriesRes] = await Promise.all([
        supabase
          .from('plants')
          .select('*, genus:genus_id(id, name)')
          .order('created_at', { ascending: false }),
        supabase.from('finance_categories').select('*').order('name'),
      ]);

      if (plantsRes.data) setPlants(plantsRes.data);
      if (categoriesRes.data) setCategories(categoriesRes.data);
    } catch (err) {
      console.error('Error loading reference data:', err);
    }
  };

  const loadFinance = async () => {
    try {
      const { data, error } = await supabase
        .from('finance')
        .select('*')
        .eq('id', financeId)
        .single();

      if (error) throw error;

      if (data) {
        setFormData({
          date: data.date,
          type: data.type,
          category_id: data.category_id || '',
          description: data.description || '',
          amount: data.amount.toString(),
          related_plant_id: data.related_plant_id?.toString() || '',
          payment_method: data.payment_method || '',
        });
      }
    } catch (err) {
      console.error('Error loading finance:', err);
      setError('Failed to load finance data');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.category_id || !formData.amount) {
      setError('Please select a category and enter an amount');
      return;
    }

    setSaving(true);
    setError('');

    try {
      const financeData = {
        user_id: user?.id,
        date: formData.date,
        type: formData.type,
        category_id: formData.category_id,
        description: formData.description || null,
        amount: parseFloat(formData.amount),
        related_plant_id: formData.related_plant_id ? parseInt(formData.related_plant_id) : null,
        payment_method: formData.payment_method || null,
      };

      if (isEditing) {
        const { error } = await supabase
          .from('finance')
          .update(financeData)
          .eq('id', financeId);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('finance').insert(financeData);

        if (error) throw error;
      }

      router.back();
    } catch (err: any) {
      console.error('Error saving finance:', err);
      setError(err.message || 'Failed to save transaction');
    } finally {
      setSaving(false);
    }
  };

  const plantOptions = plants.map((plant) => ({
    id: plant.id.toString(),
    name: getPlantDisplayName(plant, plant.genus),
  }));

  const filteredCategories = categories.filter(
    (cat) => cat.type === formData.type.toLowerCase()
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {isEditing ? 'Edit Transaction' : 'Add Transaction'}
        </Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={saving}
          style={styles.saveButton}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#4a7c2c" />
          ) : (
            <Text style={styles.saveButtonText}>Save</Text>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Transaction Details</Text>

          <DatePicker
            label="Date"
            value={formData.date}
            onValueChange={(value) => setFormData({ ...formData, date: value })}
          />

          <Picker
            label="Type"
            value={formData.type}
            options={[
              { id: 'Income', name: 'Income' },
              { id: 'Expense', name: 'Expense' },
            ]}
            onValueChange={(value) =>
              setFormData({ ...formData, type: value as any, category_id: '' })
            }
            placeholder="Select type"
            required
          />

          <Picker
            label="Category"
            value={formData.category_id}
            options={filteredCategories}
            onValueChange={(value) => setFormData({ ...formData, category_id: value })}
            placeholder="Select category"
            required
          />

          <Text style={styles.label}>
            Amount (DKK) <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={styles.input}
            value={formData.amount}
            onChangeText={(text) => setFormData({ ...formData, amount: text })}
            keyboardType="decimal-pad"
            placeholder="0.00"
            placeholderTextColor="#999"
          />

          <Text style={styles.label}>Description</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={formData.description}
            onChangeText={(text) => setFormData({ ...formData, description: text })}
            placeholder="Add notes about this transaction..."
            placeholderTextColor="#999"
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Additional Information</Text>

          <Picker
            label="Related Plant"
            value={formData.related_plant_id}
            options={plantOptions}
            onValueChange={(value) => setFormData({ ...formData, related_plant_id: value })}
            placeholder="Select plant (optional)"
          />

          <Text style={styles.label}>Payment Method</Text>
          <TextInput
            style={styles.input}
            value={formData.payment_method}
            onChangeText={(text) => setFormData({ ...formData, payment_method: text })}
            placeholder="e.g., Cash, Credit Card, Bank Transfer"
            placeholderTextColor="#999"
          />
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  saveButton: {
    minWidth: 60,
    alignItems: 'flex-end',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 14,
    textAlign: 'center',
    padding: 16,
    backgroundColor: '#ffebee',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
  },
  section: {
    backgroundColor: '#fff',
    padding: 16,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d5016',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
    marginTop: 12,
  },
  required: {
    color: '#d32f2f',
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    minHeight: 80,
    paddingTop: 12,
  },
});
