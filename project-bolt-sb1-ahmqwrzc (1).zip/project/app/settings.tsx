import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { X, Check } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { UserPreferences } from '@/types/database';

export default function SettingsScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);

  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = async () => {
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setPreferences(data);
      } else {
        const defaultPrefs: Partial<UserPreferences> = {
          user_id: user?.id || '',
          show_origin: true,
          show_status: true,
          show_location: true,
          show_medium: true,
          show_nutrients: true,
          show_maintenance_thresholds: true,
          default_flush_yellow_days: 30,
          default_flush_red_days: 60,
          default_repot_yellow_months: 6,
          default_repot_red_months: 12,
          plant_name_format: 'number_genus_species',
          default_plant_sort: 'created_desc',
          enable_care_reminders: true,
          reminder_advance_days: 3,
        };

        const { data: newPrefs, error: insertError } = await supabase
          .from('user_preferences')
          .insert(defaultPrefs)
          .select()
          .single();

        if (insertError) throw insertError;
        if (newPrefs) setPreferences(newPrefs);
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
      Alert.alert('Error', 'Failed to load preferences');
    } finally {
      setLoading(false);
    }
  };

  const updatePreference = async (key: keyof UserPreferences, value: any) => {
    if (!preferences) return;

    const updatedPrefs = { ...preferences, [key]: value };
    setPreferences(updatedPrefs);

    try {
      const { error } = await supabase
        .from('user_preferences')
        .update({ [key]: value })
        .eq('user_id', user?.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating preference:', error);
      Alert.alert('Error', 'Failed to save preference');
      setPreferences(preferences);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      router.back();
    } catch (error) {
      console.error('Error saving preferences:', error);
      Alert.alert('Error', 'Failed to save preferences');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  if (!preferences) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <Text style={styles.errorText}>Failed to load preferences</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings</Text>
        <TouchableOpacity
          onPress={handleSave}
          disabled={saving}
          style={styles.saveButton}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#4a7c2c" />
          ) : (
            <Check size={24} color="#4a7c2c" />
          )}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Field Visibility</Text>
          <Text style={styles.sectionDescription}>
            Control which fields are shown by default when adding or editing plants.
            You can override these settings for individual plants.
          </Text>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Origin Information</Text>
              <Text style={styles.settingDescription}>
                Show origin type, purchase/propagation dates, and costs
              </Text>
            </View>
            <Switch
              value={preferences.show_origin}
              onValueChange={(value) => updatePreference('show_origin', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_origin ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Status</Text>
              <Text style={styles.settingDescription}>
                Show plant status and sold date
              </Text>
            </View>
            <Switch
              value={preferences.show_status}
              onValueChange={(value) => updatePreference('show_status', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_status ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Location / Zone</Text>
              <Text style={styles.settingDescription}>
                Show location zone selection
              </Text>
            </View>
            <Switch
              value={preferences.show_location}
              onValueChange={(value) => updatePreference('show_location', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_location ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Growing Medium</Text>
              <Text style={styles.settingDescription}>
                Show growing medium selection
              </Text>
            </View>
            <Switch
              value={preferences.show_medium}
              onValueChange={(value) => updatePreference('show_medium', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_medium ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Nutrients</Text>
              <Text style={styles.settingDescription}>
                Show nutrient type selection
              </Text>
            </View>
            <Switch
              value={preferences.show_nutrients}
              onValueChange={(value) => updatePreference('show_nutrients', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_nutrients ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Maintenance Thresholds</Text>
              <Text style={styles.settingDescription}>
                Show flush and repot threshold settings
              </Text>
            </View>
            <Switch
              value={preferences.show_maintenance_thresholds}
              onValueChange={(value) => updatePreference('show_maintenance_thresholds', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.show_maintenance_thresholds ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Display Preferences</Text>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Care Reminders</Text>
              <Text style={styles.settingDescription}>
                Enable notifications for plant care
              </Text>
            </View>
            <Switch
              value={preferences.enable_care_reminders}
              onValueChange={(value) => updatePreference('enable_care_reminders', value)}
              trackColor={{ false: '#e0e0e0', true: '#a5d6a7' }}
              thumbColor={preferences.enable_care_reminders ? '#4a7c2c' : '#f4f3f4'}
            />
          </View>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>About Field Visibility</Text>
          <Text style={styles.infoText}>
            These settings control the default visibility of fields throughout the app.
            You can still enable or disable specific fields for individual plants when needed.
            This helps keep your plant management simple by hiding features you don't use.
          </Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  saveButton: {
    padding: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#999',
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: '#fff',
    paddingVertical: 16,
    marginTop: 16,
    marginHorizontal: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d5016',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  sectionDescription: {
    fontSize: 13,
    color: '#666',
    paddingHorizontal: 16,
    marginBottom: 16,
    lineHeight: 18,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  settingLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: '#333',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 13,
    color: '#999',
  },
  infoCard: {
    backgroundColor: '#e8f5e9',
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#4a7c2c',
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d5016',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 13,
    color: '#4a7c2c',
    lineHeight: 18,
  },
});
