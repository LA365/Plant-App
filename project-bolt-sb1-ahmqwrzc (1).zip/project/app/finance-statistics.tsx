import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { X, TrendingUp, TrendingDown, DollarSign } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { FinanceWithRelations } from '@/types/database';

interface FinanceSummary {
  totalIncome: number;
  totalExpense: number;
  netProfit: number;
  transactionCount: number;
}

interface CategoryBreakdown {
  category: string;
  amount: number;
  percentage: number;
  type: 'Income' | 'Expense';
}

export default function FinanceStatisticsScreen() {
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<FinanceSummary>({
    totalIncome: 0,
    totalExpense: 0,
    netProfit: 0,
    transactionCount: 0,
  });
  const [topIncomeCategories, setTopIncomeCategories] = useState<CategoryBreakdown[]>([]);
  const [topExpenseCategories, setTopExpenseCategories] = useState<CategoryBreakdown[]>([]);

  useEffect(() => {
    loadStatistics();
  }, []);

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase
        .from('finance')
        .select(`
          *,
          category:category_id(id, name, type)
        `)
        .order('date', { ascending: false });

      if (error) throw error;

      if (data) {
        const income = data
          .filter((t) => t.type === 'Income')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        const expense = data
          .filter((t) => t.type === 'Expense')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        setSummary({
          totalIncome: income,
          totalExpense: expense,
          netProfit: income - expense,
          transactionCount: data.length,
        });

        const incomeByCategory = new Map<string, number>();
        const expenseByCategory = new Map<string, number>();

        data.forEach((transaction) => {
          const categoryName = transaction.category?.name || 'Uncategorized';
          const amount = Number(transaction.amount);

          if (transaction.type === 'Income') {
            incomeByCategory.set(
              categoryName,
              (incomeByCategory.get(categoryName) || 0) + amount
            );
          } else {
            expenseByCategory.set(
              categoryName,
              (expenseByCategory.get(categoryName) || 0) + amount
            );
          }
        });

        const topIncome = Array.from(incomeByCategory.entries())
          .map(([category, amount]) => ({
            category,
            amount,
            percentage: income > 0 ? (amount / income) * 100 : 0,
            type: 'Income' as const,
          }))
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 5);

        const topExpense = Array.from(expenseByCategory.entries())
          .map(([category, amount]) => ({
            category,
            amount,
            percentage: expense > 0 ? (amount / expense) * 100 : 0,
            type: 'Expense' as const,
          }))
          .sort((a, b) => b.amount - a.amount)
          .slice(0, 5);

        setTopIncomeCategories(topIncome);
        setTopExpenseCategories(topExpense);
      }
    } catch (error) {
      console.error('Error loading finance statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Finance Overview</Text>
        <TouchableOpacity onPress={() => router.push('/finance')}>
          <Text style={styles.viewAllText}>View All</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.summarySection}>
          <View style={[styles.summaryCardLarge, styles.profitCard]}>
            <DollarSign size={32} color={summary.netProfit >= 0 ? '#4caf50' : '#f44336'} />
            <Text style={styles.summaryLargeLabel}>Net Profit</Text>
            <Text
              style={[
                styles.summaryLargeValue,
                { color: summary.netProfit >= 0 ? '#4caf50' : '#f44336' }
              ]}
            >
              {summary.netProfit >= 0 ? '+' : ''}{summary.netProfit.toFixed(2)} DKK
            </Text>
            <Text style={styles.summarySubtext}>
              {summary.transactionCount} transactions
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <View style={[styles.summaryCard, styles.incomeCard]}>
              <TrendingUp size={24} color="#4caf50" />
              <Text style={styles.summaryLabel}>Total Income</Text>
              <Text style={[styles.summaryValue, { color: '#4caf50' }]}>
                {summary.totalIncome.toFixed(2)} DKK
              </Text>
            </View>

            <View style={[styles.summaryCard, styles.expenseCard]}>
              <TrendingDown size={24} color="#f44336" />
              <Text style={styles.summaryLabel}>Total Expenses</Text>
              <Text style={[styles.summaryValue, { color: '#f44336' }]}>
                {summary.totalExpense.toFixed(2)} DKK
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Income Sources</Text>
          {topIncomeCategories.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>No income recorded yet</Text>
            </View>
          ) : (
            topIncomeCategories.map((item, index) => (
              <View key={index} style={styles.categoryCard}>
                <View style={styles.categoryInfo}>
                  <Text style={styles.categoryName}>{item.category}</Text>
                  <View style={styles.progressBarContainer}>
                    <View
                      style={[
                        styles.progressBar,
                        styles.incomeBar,
                        { width: `${item.percentage}%` }
                      ]}
                    />
                  </View>
                </View>
                <View style={styles.categoryAmount}>
                  <Text style={[styles.amountText, { color: '#4caf50' }]}>
                    {item.amount.toFixed(2)} DKK
                  </Text>
                  <Text style={styles.percentageText}>{item.percentage.toFixed(1)}%</Text>
                </View>
              </View>
            ))
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Expense Categories</Text>
          {topExpenseCategories.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>No expenses recorded yet</Text>
            </View>
          ) : (
            topExpenseCategories.map((item, index) => (
              <View key={index} style={styles.categoryCard}>
                <View style={styles.categoryInfo}>
                  <Text style={styles.categoryName}>{item.category}</Text>
                  <View style={styles.progressBarContainer}>
                    <View
                      style={[
                        styles.progressBar,
                        styles.expenseBar,
                        { width: `${item.percentage}%` }
                      ]}
                    />
                  </View>
                </View>
                <View style={styles.categoryAmount}>
                  <Text style={[styles.amountText, { color: '#f44336' }]}>
                    {item.amount.toFixed(2)} DKK
                  </Text>
                  <Text style={styles.percentageText}>{item.percentage.toFixed(1)}%</Text>
                </View>
              </View>
            ))
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  viewAllText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  summarySection: {
    padding: 16,
    gap: 12,
  },
  summaryCardLarge: {
    backgroundColor: '#fff',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  profitCard: {
    borderWidth: 2,
    borderColor: '#e0e0e0',
  },
  summaryLargeLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 12,
    marginBottom: 8,
  },
  summaryLargeValue: {
    fontSize: 32,
    fontWeight: 'bold',
  },
  summarySubtext: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: 12,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  incomeCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#4caf50',
  },
  expenseCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#f44336',
  },
  summaryLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
    marginBottom: 8,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  emptyState: {
    backgroundColor: '#fff',
    padding: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
  },
  categoryCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    gap: 12,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  progressBarContainer: {
    height: 6,
    backgroundColor: '#e0e0e0',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 3,
  },
  incomeBar: {
    backgroundColor: '#4caf50',
  },
  expenseBar: {
    backgroundColor: '#f44336',
  },
  categoryAmount: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  amountText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  percentageText: {
    fontSize: 12,
    color: '#999',
  },
});
