import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl, ActivityIndicator as RNActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Activity, Plus, Edit, Trash2 } from 'lucide-react-native';
import { router, useFocusEffect } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { ActivityLogWithRelations } from '@/types/database';

export default function ActivityScreen() {
  const [activities, setActivities] = useState<ActivityLogWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('activity_log')
        .select(`
          *,
          plant:plant_id(id, genus_id, species_variety),
          action_type:action_type_id(id, name)
        `)
        .order('date', { ascending: false });

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchActivities();
    }, [])
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchActivities();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const handleDeleteActivity = (activityId: number) => {
    Alert.alert(
      'Delete Activity',
      'Are you sure you want to delete this activity? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('activity_log')
                .delete()
                .eq('id', activityId);

              if (error) throw error;
              fetchActivities();
            } catch (error) {
              console.error('Error deleting activity:', error);
              Alert.alert('Error', 'Failed to delete activity');
            }
          },
        },
      ]
    );
  };

  const renderActivityItem = ({ item }: { item: ActivityLogWithRelations }) => {
    return (
      <View style={styles.activityCard}>
        <View style={styles.activityHeader}>
          <Text style={styles.activityType}>{item.action_type?.name}</Text>
          <View style={styles.activityActions}>
            <TouchableOpacity
              onPress={() => router.push(`/activity-form?id=${item.id}`)}
              style={styles.actionButton}
            >
              <Edit size={18} color="#4a7c2c" />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => handleDeleteActivity(item.id)}
              style={styles.actionButton}
            >
              <Trash2 size={18} color="#d32f2f" />
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.activityDate}>{formatDate(item.date)}</Text>

        {item.plant && (
          <Text style={styles.plantName}>
            Plant #{item.plant.id} - {item.plant.species_variety || 'Unknown'}
          </Text>
        )}

        {item.details && <Text style={styles.activityDetails}>{item.details}</Text>}

        <View style={styles.activityFooter}>
          {item.quantity_count > 0 && (
            <Text style={styles.activityMeta}>Qty: {item.quantity_count}</Text>
          )}
          {item.cost_income !== 0 && (
            <Text style={[styles.activityMeta, item.cost_income > 0 ? styles.income : styles.expense]}>
              {item.cost_income > 0 ? '+' : ''}{item.cost_income} DKK
            </Text>
          )}
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <RNActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Activity Log</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => router.push('/activity-form')}
        >
          <Plus size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {activities.length === 0 ? (
        <View style={styles.emptyState}>
          <Activity size={64} color="#999" />
          <Text style={styles.emptyText}>No activities yet</Text>
          <Text style={styles.emptySubtext}>Log your first plant activity</Text>
        </View>
      ) : (
        <FlatList
          data={activities}
          renderItem={renderActivityItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#4a7c2c" />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2d5016',
  },
  addButton: {
    backgroundColor: '#4a7c2c',
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: 16,
    gap: 12,
  },
  activityCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  activityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  activityType: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4a7c2c',
    flex: 1,
  },
  activityActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    padding: 4,
  },
  activityDate: {
    fontSize: 13,
    color: '#999',
    marginBottom: 8,
  },
  plantName: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  activityDetails: {
    fontSize: 14,
    color: '#333',
    marginBottom: 8,
  },
  activityFooter: {
    flexDirection: 'row',
    gap: 16,
  },
  activityMeta: {
    fontSize: 13,
    color: '#666',
  },
  income: {
    color: '#4caf50',
    fontWeight: '600',
  },
  expense: {
    color: '#f44336',
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 100,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
});
