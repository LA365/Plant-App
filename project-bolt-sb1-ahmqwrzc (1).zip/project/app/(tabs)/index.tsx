import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { AlertTriangle, Circle, AlertCircle } from 'lucide-react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { PlantWithRelations } from '@/types/database';
import { getFlushStatus, getRepotStatus, getStatusColor, getPlantDisplayName } from '@/utils/plantStatus';

export default function DashboardScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [metrics, setMetrics] = useState({
    activePlants: 0,
    totalCorms: 0,
    netProfit: 0,
    totalActivities: 0,
    plantsNeedingSetup: 0,
  });
  const [plantsNeedingAttention, setPlantsNeedingAttention] = useState<PlantWithRelations[]>([]);
  const [plantsNeedingSetup, setPlantsNeedingSetup] = useState<PlantWithRelations[]>([]);

  const fetchDashboardData = async () => {
    try {
      const [plantsRes, setupPlantsRes, financeRes, activitiesRes] = await Promise.all([
        supabase
          .from('plants')
          .select(`
            *,
            genus:genus_id(id, name),
            location_zone:location_zone_id(id, name)
          `)
          .eq('status', 'Active'),
        supabase
          .from('plants')
          .select(`
            *,
            genus:genus_id(id, name),
            location_zone:location_zone_id(id, name)
          `)
          .eq('action_required', true)
          .eq('status', 'Active')
          .order('created_at', { ascending: false }),
        supabase.from('finance').select('type, amount'),
        supabase.from('activity_log').select('id', { count: 'exact', head: true }),
      ]);

      if (plantsRes.data) {
        const totalCorms = plantsRes.data.reduce(
          (sum, plant) => sum + (plant.total_corms_produced || 0),
          0
        );

        const needsAttention = plantsRes.data.filter((plant) => {
          const flushStatus = getFlushStatus(plant);
          const repotStatus = getRepotStatus(plant);
          return flushStatus === 'yellow' || flushStatus === 'red' || repotStatus === 'yellow' || repotStatus === 'red';
        });

        needsAttention.sort((a, b) => {
          const aFlush = getFlushStatus(a);
          const aRepot = getRepotStatus(a);
          const bFlush = getFlushStatus(b);
          const bRepot = getRepotStatus(b);

          const aHasRed = aFlush === 'red' || aRepot === 'red';
          const bHasRed = bFlush === 'red' || bRepot === 'red';

          if (aHasRed && !bHasRed) return -1;
          if (!aHasRed && bHasRed) return 1;
          return 0;
        });

        setMetrics((prev) => ({
          ...prev,
          activePlants: plantsRes.data.length,
          totalCorms,
        }));

        setPlantsNeedingAttention(needsAttention);
      }

      if (setupPlantsRes.data) {
        setPlantsNeedingSetup(setupPlantsRes.data);
        setMetrics((prev) => ({
          ...prev,
          plantsNeedingSetup: setupPlantsRes.data.length,
        }));
      }

      if (financeRes.data) {
        const income = financeRes.data
          .filter((t) => t.type === 'Income')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        const expense = financeRes.data
          .filter((t) => t.type === 'Expense')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        setMetrics((prev) => ({
          ...prev,
          netProfit: income - expense,
        }));
      }

      if (activitiesRes.count !== null) {
        setMetrics((prev) => ({
          ...prev,
          totalActivities: activitiesRes.count || 0,
        }));
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchDashboardData();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#4a7c2c" />
        }
      >
        <Text style={styles.title}>Dashboard</Text>
        <Text style={styles.subtitle}>Welcome back!</Text>

        {plantsNeedingSetup.length > 0 && (
          <View style={styles.alertBanner}>
            <AlertCircle size={24} color="#ff9800" />
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>
                {plantsNeedingSetup.length} Plant{plantsNeedingSetup.length > 1 ? 's' : ''} Need Setup
              </Text>
              <Text style={styles.alertText}>
                Complete setup for newly propagated plants
              </Text>
            </View>
            <TouchableOpacity
              style={styles.alertButton}
              onPress={() => router.push('/plants')}
            >
              <Text style={styles.alertButtonText}>View</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.metricsGrid}>
          <TouchableOpacity
            style={styles.metricCard}
            onPress={() => router.push('/plants')}
          >
            <Text style={styles.metricValue}>{metrics.activePlants}</Text>
            <Text style={styles.metricLabel}>Active Plants</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.metricCard}
            onPress={() => router.push('/corms-statistics')}
          >
            <Text style={styles.metricValue}>{metrics.totalCorms}</Text>
            <Text style={styles.metricLabel}>Total Corms</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.metricCard}
            onPress={() => router.push('/finance-statistics')}
          >
            <Text style={[styles.metricValue, { color: metrics.netProfit >= 0 ? '#4caf50' : '#f44336' }]}>
              {metrics.netProfit.toFixed(0)} DKK
            </Text>
            <Text style={styles.metricLabel}>Net Profit</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.metricCard}
            onPress={() => router.push('/activity')}
          >
            <Text style={styles.metricValue}>{metrics.totalActivities}</Text>
            <Text style={styles.metricLabel}>Activities</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Plants Needing Attention</Text>
          {plantsNeedingAttention.length === 0 ? (
            <View style={styles.emptyState}>
              <AlertTriangle size={48} color="#999" />
              <Text style={styles.emptyText}>No plants need attention</Text>
            </View>
          ) : (
            <View>
              {plantsNeedingAttention.map((plant) => {
                const flushStatus = getFlushStatus(plant);
                const repotStatus = getRepotStatus(plant);
                const displayName = getPlantDisplayName(plant, plant.genus);

                return (
                  <TouchableOpacity
                    key={plant.id}
                    style={styles.attentionCard}
                    onPress={() => router.push(`/plant-detail?id=${plant.id}`)}
                  >
                    <View style={styles.attentionHeader}>
                      <Text style={styles.attentionPlantName}>{displayName}</Text>
                      {plant.location_zone && (
                        <Text style={styles.attentionLocation}>{plant.location_zone.name}</Text>
                      )}
                    </View>
                    <View style={styles.attentionStatusRow}>
                      <View style={styles.statusItem}>
                        <Circle
                          size={12}
                          color={getStatusColor(flushStatus)}
                          fill={getStatusColor(flushStatus)}
                        />
                        <Text style={styles.statusLabel}>Flush</Text>
                      </View>
                      <View style={styles.statusItem}>
                        <Circle
                          size={12}
                          color={getStatusColor(repotStatus)}
                          fill={getStatusColor(repotStatus)}
                        />
                        <Text style={styles.statusLabel}>Repot</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2d5016',
    paddingHorizontal: 16,
    marginTop: 16,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 12,
  },
  metricCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2d5016',
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 14,
    color: '#666',
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  emptyState: {
    backgroundColor: '#fff',
    padding: 32,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 8,
  },
  attentionCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  attentionHeader: {
    marginBottom: 8,
  },
  attentionPlantName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  attentionLocation: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  attentionStatusRow: {
    flexDirection: 'row',
    gap: 16,
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
  },
  alertBanner: {
    backgroundColor: '#fff3e0',
    borderLeftWidth: 4,
    borderLeftColor: '#ff9800',
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#e65100',
    marginBottom: 4,
  },
  alertText: {
    fontSize: 14,
    color: '#ef6c00',
  },
  alertButton: {
    backgroundColor: '#ff9800',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
  },
  alertButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
});
