import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl, ActivityIndicator, Alert, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Sprout, Plus, Circle, AlertCircle, CheckSquare, Square, Trash2, MapPin, Activity } from 'lucide-react-native';
import { router, useFocusEffect } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { PlantWithRelations, GenusOption, LocationZone } from '@/types/database';
import { getFlushStatus, getRepotStatus, getStatusColor, getPlantDisplayName } from '@/utils/plantStatus';
import { PlantSearch, PlantFilters } from '@/components/PlantSearch';

export default function PlantsScreen() {
  const [plants, setPlants] = useState<PlantWithRelations[]>([]);
  const [filteredPlants, setFilteredPlants] = useState<PlantWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedPlants, setSelectedPlants] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<PlantFilters>({});
  const [genera, setGenera] = useState<GenusOption[]>([]);
  const [locations, setLocations] = useState<LocationZone[]>([]);

  const fetchPlants = async () => {
    try {
      const { data, error } = await supabase
        .from('plants')
        .select(`
          *,
          genus:genus_id(id, name),
          current_medium:current_medium_id(id, name),
          nutrient_type:nutrient_type_id(id, name),
          location_zone:location_zone_id(id, name),
          thumbnail_photo:thumbnail_photo_id(id, image_url, local_path)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPlants(data || []);
      applyFilters(data || [], searchQuery, filters);
    } catch (error) {
      console.error('Error fetching plants:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadFilterOptions = async () => {
    try {
      const [generaRes, locationsRes] = await Promise.all([
        supabase.from('genus_options').select('*').order('name'),
        supabase.from('location_zones').select('*').order('name'),
      ]);

      if (generaRes.data) setGenera(generaRes.data);
      if (locationsRes.data) setLocations(locationsRes.data);
    } catch (error) {
      console.error('Error loading filter options:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchPlants();
      loadFilterOptions();
    }, [])
  );

  useEffect(() => {
    applyFilters(plants, searchQuery, filters);
  }, [searchQuery, filters]);

  const applyFilters = (plantList: PlantWithRelations[], query: string, activeFilters: PlantFilters) => {
    let filtered = [...plantList];

    if (query) {
      const lowerQuery = query.toLowerCase();
      filtered = filtered.filter((plant) => {
        const displayName = getPlantDisplayName(plant, plant.genus).toLowerCase();
        const genusName = plant.genus?.name.toLowerCase() || '';
        const speciesVariety = plant.species_variety?.toLowerCase() || '';
        return displayName.includes(lowerQuery) ||
               genusName.includes(lowerQuery) ||
               speciesVariety.includes(lowerQuery) ||
               plant.unique_number?.toLowerCase().includes(lowerQuery);
      });
    }

    if (activeFilters.status) {
      filtered = filtered.filter((plant) => plant.status === activeFilters.status);
    }

    if (activeFilters.genus) {
      filtered = filtered.filter((plant) => plant.genus_id === activeFilters.genus);
    }

    if (activeFilters.location) {
      filtered = filtered.filter((plant) => plant.location_zone_id === activeFilters.location);
    }

    if (activeFilters.needsAttention) {
      filtered = filtered.filter((plant) => {
        const flushStatus = getFlushStatus(plant);
        const repotStatus = getRepotStatus(plant);
        return flushStatus !== 'green' || repotStatus !== 'green';
      });
    }

    if (activeFilters.needsSetup) {
      filtered = filtered.filter((plant) => plant.action_required);
    }

    setFilteredPlants(filtered);
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilterChange = (newFilters: PlantFilters) => {
    setFilters(newFilters);
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchPlants();
  };

  const toggleSelectionMode = () => {
    setSelectionMode(!selectionMode);
    setSelectedPlants(new Set());
  };

  const togglePlantSelection = (plantId: number) => {
    const newSelection = new Set(selectedPlants);
    if (newSelection.has(plantId)) {
      newSelection.delete(plantId);
    } else {
      newSelection.add(plantId);
    }
    setSelectedPlants(newSelection);
  };

  const selectAll = () => {
    const allIds = new Set(plants.map(p => p.id));
    setSelectedPlants(allIds);
  };

  const clearSelection = () => {
    setSelectedPlants(new Set());
  };

  const handleBulkActivity = () => {
    if (selectedPlants.size === 0) {
      Alert.alert('No Selection', 'Please select at least one plant');
      return;
    }
    const plantIds = JSON.stringify(Array.from(selectedPlants));
    router.push(`/bulk-activity?plantIds=${encodeURIComponent(plantIds)}`);
  };

  const handleBulkDelete = () => {
    if (selectedPlants.size === 0) {
      Alert.alert('No Selection', 'Please select at least one plant');
      return;
    }
    Alert.alert(
      'Delete Plants',
      `Are you sure you want to delete ${selectedPlants.size} plant${selectedPlants.size > 1 ? 's' : ''}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('plants')
                .delete()
                .in('id', Array.from(selectedPlants));

              if (error) throw error;
              fetchPlants();
              setSelectionMode(false);
              setSelectedPlants(new Set());
            } catch (error) {
              console.error('Error deleting plants:', error);
              Alert.alert('Error', 'Failed to delete plants');
            }
          },
        },
      ]
    );
  };

  const renderPlantItem = ({ item }: { item: PlantWithRelations }) => {
    const flushStatus = getFlushStatus(item);
    const repotStatus = getRepotStatus(item);
    const displayName = getPlantDisplayName(item, item.genus);

    const isSelected = selectedPlants.has(item.id);

    return (
      <TouchableOpacity
        style={[
          styles.plantCard,
          item.action_required && styles.plantCardSetupNeeded,
          isSelected && styles.plantCardSelected,
        ]}
        onPress={() => {
          if (selectionMode) {
            togglePlantSelection(item.id);
          } else {
            router.push(`/plant-detail?id=${item.id}`);
          }
        }}
        onLongPress={() => {
          if (!selectionMode) {
            setSelectionMode(true);
            togglePlantSelection(item.id);
          }
        }}
      >
        <View style={styles.plantCardContent}>
          {item.thumbnail_photo && (
            <Image
              source={{ uri: (item.thumbnail_photo as any).image_url || (item.thumbnail_photo as any).local_path }}
              style={styles.plantThumbnail}
            />
          )}
          <View style={styles.plantInfo}>
            <View style={styles.plantHeader}>
              {selectionMode && (
                <View style={styles.checkbox}>
                  {isSelected ? (
                    <CheckSquare size={24} color="#4a7c2c" />
                  ) : (
                    <Square size={24} color="#999" />
                  )}
                </View>
              )}
              <Text style={[styles.plantName, selectionMode && styles.plantNameWithCheckbox]}>
                {displayName}
              </Text>
              <View style={styles.statusBadgeRow}>
                {item.action_required && (
                  <View style={styles.setupBadge}>
                    <AlertCircle size={14} color="#ff9800" />
                    <Text style={styles.setupBadgeText}>Setup</Text>
                  </View>
                )}
                <View style={styles.statusBadge}>
                  <Text style={[styles.statusText, { color: item.status === 'Active' ? '#4a7c2c' : '#999' }]}>
                    {item.status}
                  </Text>
                </View>
              </View>
            </View>

            {item.location_zone && (
              <Text style={styles.plantLocation}>{item.location_zone.name}</Text>
            )}

            <View style={styles.statusRow}>
              <View style={styles.statusItem}>
                <Circle size={12} color={getStatusColor(flushStatus)} fill={getStatusColor(flushStatus)} />
                <Text style={styles.statusLabel}>Flush</Text>
              </View>
              <View style={styles.statusItem}>
                <Circle size={12} color={getStatusColor(repotStatus)} fill={getStatusColor(repotStatus)} />
                <Text style={styles.statusLabel}>Repot</Text>
              </View>
              {item.total_corms_produced > 0 && (
                <Text style={styles.cormsText}>{item.total_corms_produced} corms</Text>
              )}
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Plants</Text>
        <View style={styles.headerActions}>
          {!selectionMode ? (
            <>
              <TouchableOpacity style={styles.iconButton} onPress={toggleSelectionMode}>
                <CheckSquare size={24} color="#4a7c2c" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.addButton} onPress={() => router.push('/plant-form')}>
                <Plus size={24} color="#fff" />
              </TouchableOpacity>
            </>
          ) : (
            <TouchableOpacity onPress={toggleSelectionMode}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {!selectionMode && (
        <PlantSearch
          onSearchChange={handleSearchChange}
          onFilterChange={handleFilterChange}
          availableFilters={{
            statuses: ['Active', 'Sold', 'Dormant', 'Dead'],
            genera: genera,
            locations: locations,
          }}
        />
      )}

      {selectionMode && (
        <View style={styles.selectionToolbar}>
          <View style={styles.selectionInfo}>
            <Text style={styles.selectionCount}>
              {selectedPlants.size} selected
            </Text>
            <View style={styles.selectionActions}>
              <TouchableOpacity style={styles.toolbarButton} onPress={selectAll}>
                <Text style={styles.toolbarButtonText}>Select All</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.toolbarButton} onPress={clearSelection}>
                <Text style={styles.toolbarButtonText}>Clear</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.bulkActions}>
            <TouchableOpacity
              style={styles.bulkActionButton}
              onPress={handleBulkActivity}
              disabled={selectedPlants.size === 0}
            >
              <Activity size={20} color={selectedPlants.size > 0 ? '#4a7c2c' : '#ccc'} />
              <Text style={[styles.bulkActionText, selectedPlants.size === 0 && styles.bulkActionTextDisabled]}>
                Activity
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.bulkActionButton}
              onPress={handleBulkDelete}
              disabled={selectedPlants.size === 0}
            >
              <Trash2 size={20} color={selectedPlants.size > 0 ? '#d32f2f' : '#ccc'} />
              <Text style={[styles.bulkActionText, selectedPlants.size === 0 && styles.bulkActionTextDisabled]}>
                Delete
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {filteredPlants.length === 0 ? (
        <View style={styles.emptyState}>
          <Sprout size={64} color="#999" />
          <Text style={styles.emptyText}>
            {plants.length === 0 ? 'No plants yet' : 'No plants found'}
          </Text>
          <Text style={styles.emptySubtext}>
            {plants.length === 0 ? 'Add your first plant to get started' : 'Try adjusting your search or filters'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredPlants}
          renderItem={renderPlantItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#4a7c2c" />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2d5016',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconButton: {
    padding: 4,
  },
  cancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#d32f2f',
  },
  addButton: {
    backgroundColor: '#4a7c2c',
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectionToolbar: {
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  selectionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  selectionCount: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4a7c2c',
  },
  selectionActions: {
    flexDirection: 'row',
    gap: 12,
  },
  toolbarButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#f0f0f0',
    borderRadius: 6,
  },
  toolbarButtonText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#666',
  },
  bulkActions: {
    flexDirection: 'row',
    gap: 12,
  },
  bulkActionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  bulkActionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  bulkActionTextDisabled: {
    color: '#ccc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    padding: 16,
    gap: 12,
  },
  plantCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  plantCardContent: {
    flexDirection: 'row',
  },
  plantThumbnail: {
    width: 80,
    height: 80,
    backgroundColor: '#f0f0f0',
  },
  plantInfo: {
    flex: 1,
    padding: 16,
  },
  plantCardSelected: {
    borderWidth: 2,
    borderColor: '#4a7c2c',
    backgroundColor: '#f1f8f1',
  },
  plantHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  statusBadgeRow: {
    flexDirection: 'row',
    gap: 8,
  },
  plantCardSetupNeeded: {
    borderLeftWidth: 4,
    borderLeftColor: '#ff9800',
  },
  setupBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#fff3e0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  setupBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ff9800',
  },
  checkbox: {
    marginRight: 12,
  },
  plantName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    flex: 1,
  },
  plantNameWithCheckbox: {
    flex: 0,
    marginRight: 8,
  },
  statusBadge: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  plantLocation: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
  },
  cormsText: {
    fontSize: 14,
    color: '#4a7c2c',
    fontWeight: '600',
    marginLeft: 'auto',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 100,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
});
