import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl, ActivityIndicator, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Wallet, Plus, TrendingUp, TrendingDown } from 'lucide-react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { FinanceWithRelations } from '@/types/database';

export default function FinanceScreen() {
  const [transactions, setTransactions] = useState<FinanceWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);

  const fetchFinance = async () => {
    try {
      const { data, error } = await supabase
        .from('finance')
        .select(`
          *,
          category:category_id(id, name, type)
        `)
        .order('date', { ascending: false });

      if (error) throw error;

      if (data) {
        setTransactions(data);

        const income = data
          .filter((t) => t.type === 'Income')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        const expense = data
          .filter((t) => t.type === 'Expense')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        setTotalIncome(income);
        setTotalExpense(expense);
      }
    } catch (error) {
      console.error('Error fetching finance:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFinance();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchFinance();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const renderTransactionItem = ({ item }: { item: FinanceWithRelations }) => {
    const isIncome = item.type === 'Income';

    return (
      <TouchableOpacity style={styles.transactionCard}>
        <View style={styles.transactionHeader}>
          <View style={styles.transactionTitleRow}>
            {isIncome ? (
              <TrendingUp size={20} color="#4caf50" />
            ) : (
              <TrendingDown size={20} color="#f44336" />
            )}
            <Text style={styles.transactionCategory}>{item.category?.name}</Text>
          </View>
          <Text style={[styles.transactionAmount, isIncome ? styles.income : styles.expense]}>
            {isIncome ? '+' : '-'}{item.amount} DKK
          </Text>
        </View>

        {item.description && (
          <Text style={styles.transactionDescription}>{item.description}</Text>
        )}

        <View style={styles.transactionFooter}>
          <Text style={styles.transactionDate}>{formatDate(item.date)}</Text>
          {item.payment_method && (
            <Text style={styles.transactionMeta}>{item.payment_method}</Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  const netProfit = totalIncome - totalExpense;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Finance</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => router.push('/finance-form')}
        >
          <Plus size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {transactions.length === 0 ? (
        <View style={styles.emptyState}>
          <Wallet size={64} color="#999" />
          <Text style={styles.emptyText}>No transactions yet</Text>
          <Text style={styles.emptySubtext}>Track your income and expenses</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#4a7c2c" />
          }
        >
          <View style={styles.summarySection}>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Income</Text>
              <Text style={[styles.summaryValue, { color: '#4caf50' }]}>
                {totalIncome.toFixed(2)} DKK
              </Text>
            </View>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryLabel}>Expenses</Text>
              <Text style={[styles.summaryValue, { color: '#f44336' }]}>
                {totalExpense.toFixed(2)} DKK
              </Text>
            </View>
            <View style={[styles.summaryCard, styles.summaryCardWide]}>
              <Text style={styles.summaryLabel}>Net Profit</Text>
              <Text style={[styles.summaryValue, { color: netProfit >= 0 ? '#4caf50' : '#f44336' }]}>
                {netProfit.toFixed(2)} DKK
              </Text>
            </View>
          </View>

          <Text style={styles.sectionTitle}>Transactions</Text>

          {transactions.map((item) => (
            <View key={item.id}>
              {renderTransactionItem({ item })}
            </View>
          ))}

          <View style={{ height: 20 }} />
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2d5016',
  },
  addButton: {
    backgroundColor: '#4a7c2c',
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContent: {
    paddingHorizontal: 16,
  },
  summarySection: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  summaryCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  summaryCardWide: {
    minWidth: '100%',
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  summaryValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  transactionCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  transactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  transactionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  transactionCategory: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  income: {
    color: '#4caf50',
  },
  expense: {
    color: '#f44336',
  },
  transactionDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  transactionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  transactionDate: {
    fontSize: 13,
    color: '#999',
  },
  transactionMeta: {
    fontSize: 13,
    color: '#999',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 100,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
});
