import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { X, Trophy } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { PlantWithRelations } from '@/types/database';
import { getPlantDisplayName } from '@/utils/plantStatus';

interface PlantWithCorms extends PlantWithRelations {
  total_corms_produced: number;
}

export default function CormsStatisticsScreen() {
  const [loading, setLoading] = useState(true);
  const [plants, setPlants] = useState<PlantWithCorms[]>([]);
  const [totalCorms, setTotalCorms] = useState(0);
  const [averageCorms, setAverageCorms] = useState(0);

  useEffect(() => {
    loadStatistics();
  }, []);

  const loadStatistics = async () => {
    try {
      const { data, error } = await supabase
        .from('plants')
        .select(`
          *,
          genus:genus_id(id, name)
        `)
        .gt('total_corms_produced', 0)
        .order('total_corms_produced', { ascending: false });

      if (error) throw error;

      if (data) {
        setPlants(data);
        const total = data.reduce((sum, plant) => sum + plant.total_corms_produced, 0);
        setTotalCorms(total);
        setAverageCorms(data.length > 0 ? total / data.length : 0);
      }
    } catch (error) {
      console.error('Error loading corms statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4a7c2c" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
          <X size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Corms Production</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.summarySection}>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryLabel}>Total Corms</Text>
            <Text style={styles.summaryValue}>{totalCorms}</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryLabel}>Average per Plant</Text>
            <Text style={styles.summaryValue}>{averageCorms.toFixed(1)}</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryLabel}>Producing Plants</Text>
            <Text style={styles.summaryValue}>{plants.length}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Leaderboard</Text>

          {plants.length === 0 ? (
            <View style={styles.emptyState}>
              <Trophy size={48} color="#999" />
              <Text style={styles.emptyText}>No corms produced yet</Text>
            </View>
          ) : (
            plants.map((plant, index) => {
              const displayName = getPlantDisplayName(plant, plant.genus);
              const percentage = totalCorms > 0 ? (plant.total_corms_produced / totalCorms * 100) : 0;

              return (
                <TouchableOpacity
                  key={plant.id}
                  style={styles.leaderboardCard}
                  onPress={() => router.push(`/plant-detail?id=${plant.id}`)}
                >
                  <View style={styles.leaderboardRank}>
                    <Text style={styles.rankNumber}>#{index + 1}</Text>
                    {index === 0 && <Trophy size={20} color="#ffd700" />}
                    {index === 1 && <Trophy size={20} color="#c0c0c0" />}
                    {index === 2 && <Trophy size={20} color="#cd7f32" />}
                  </View>

                  <View style={styles.leaderboardInfo}>
                    <Text style={styles.plantName}>{displayName}</Text>
                    <View style={styles.progressBarContainer}>
                      <View
                        style={[
                          styles.progressBar,
                          { width: `${percentage}%` }
                        ]}
                      />
                    </View>
                    <Text style={styles.cormsCount}>
                      {plant.total_corms_produced} corms ({percentage.toFixed(1)}%)
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  closeButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  summarySection: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    padding: 16,
  },
  summaryCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
    textAlign: 'center',
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4a7c2c',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  emptyState: {
    backgroundColor: '#fff',
    padding: 32,
    borderRadius: 12,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 8,
  },
  leaderboardCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    gap: 12,
  },
  leaderboardRank: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 50,
  },
  rankNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4a7c2c',
    marginBottom: 4,
  },
  leaderboardInfo: {
    flex: 1,
  },
  plantName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#4a7c2c',
    borderRadius: 4,
  },
  cormsCount: {
    fontSize: 14,
    color: '#666',
  },
});
