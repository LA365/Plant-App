export interface GenusOption {
  id: string;
  name: string;
  created_at: string;
}

export interface PlantType {
  id: string;
  user_id: string | null;
  name: string;
  description: string | null;
  is_system: boolean;
  created_at: string;
}

export interface GrowthStage {
  id: string;
  user_id: string | null;
  name: string;
  description: string | null;
  color_code: string;
  is_system: boolean;
  created_at: string;
}

export interface NutrientType {
  id: string;
  name: string;
  created_at: string;
}

export interface MediumOption {
  id: string;
  name: string;
  created_at: string;
}

export interface ActionType {
  id: string;
  name: string;
  requires_quantity: boolean;
  requires_medium: boolean;
  requires_nutrient: boolean;
  requires_cost: boolean;
  creates_children: boolean;
  child_relation_type: 'CormFrom' | 'CuttingFrom' | 'SeedFrom' | null;
  created_at: string;
}

export interface LocationZone {
  id: string;
  name: string;
  created_at: string;
}

export interface FinanceCategory {
  id: string;
  name: string;
  type: 'income' | 'expense';
  created_at: string;
}

export interface Tag {
  id: string;
  name: string;
  created_at: string;
}

export interface Plant {
  id: number;
  user_id: string;
  unique_number: string | null;
  genus_id: string | null;
  species_variety: string | null;
  origin_type: 'Purchased' | 'Propagated' | 'Cross' | 'Gifted' | null;
  origin_parent_a_id: number | null;
  origin_parent_b_id: number | null;
  bought_date: string | null;
  propagated_date: string | null;
  status: 'Active' | 'Sold' | 'Dormant' | 'Dead';
  sold_date: string | null;
  current_medium_id: string | null;
  nutrient_type_id: string | null;
  location_zone_id: string | null;
  plant_type_id: string | null;
  growth_stage_id: string | null;
  pot_size: string | null;
  thumbnail_photo_id: number | null;
  total_corms_produced: number;
  last_repot_date: string | null;
  last_flush_date: string | null;
  flush_yellow_days: number;
  flush_red_days: number;
  repot_yellow_months: number;
  repot_red_months: number;
  notes: string | null;
  action_required: boolean;
  purchase_cost: number | null;
  propagation_cost: number | null;
  plant_field_overrides: PlantFieldOverrides | null;
  created_at: string;
  updated_at: string;
}

export interface PlantFieldOverrides {
  show_origin?: boolean;
  show_status?: boolean;
  show_location?: boolean;
  show_medium?: boolean;
  show_nutrients?: boolean;
  show_maintenance_thresholds?: boolean;
}

export interface UserPreferences {
  id: string;
  user_id: string;
  show_origin: boolean;
  show_status: boolean;
  show_location: boolean;
  show_medium: boolean;
  show_nutrients: boolean;
  show_maintenance_thresholds: boolean;
  show_lifecycle_status: boolean;
  default_plant_type_id: string | null;
  default_growth_stage_id: string | null;
  default_flush_yellow_days: number;
  default_flush_red_days: number;
  default_repot_yellow_months: number;
  default_repot_red_months: number;
  plant_name_format: string;
  default_plant_sort: string;
  enable_care_reminders: boolean;
  reminder_advance_days: number;
  created_at: string;
  updated_at: string;
}

export interface PlantProfitability {
  total_cost: number;
  total_income: number;
  net_profit: number;
  roi_percentage: number;
}

export interface PlantTag {
  id: string;
  plant_id: number;
  tag_id: string;
  created_at: string;
}

export interface ActivityLog {
  id: number;
  user_id: string;
  plant_id: number;
  date: string;
  action_type_id: string;
  details: string | null;
  medium_used_id: string | null;
  nutrient_type_id: string | null;
  quantity_count: number;
  cost_income: number;
  photo_link: string | null;
  created_at: string;
  updated_at: string;
}

export interface Finance {
  id: number;
  user_id: string;
  date: string;
  type: 'Income' | 'Expense';
  category_id: string;
  description: string | null;
  amount: number;
  related_plant_id: number | null;
  payment_method: string | null;
  created_at: string;
  updated_at: string;
}

export interface Relationship {
  id: number;
  user_id: string;
  child_id: number;
  relation_type: 'CormFrom' | 'CuttingFrom' | 'SeedFrom' | 'PollenFather' | 'PollenMother';
  parent_id: number;
  date: string;
  created_at: string;
}

export interface Photo {
  id: number;
  user_id: string;
  plant_id: number;
  date: string;
  caption: string | null;
  image_url: string | null;
  local_path: string | null;
  is_thumbnail: boolean;
  created_at: string;
  updated_at: string;
}

export interface PlantWithRelations extends Plant {
  genus?: GenusOption;
  current_medium?: MediumOption;
  nutrient_type?: NutrientType;
  location_zone?: LocationZone;
  plant_type?: PlantType;
  growth_stage?: GrowthStage;
  thumbnail_photo?: Photo;
  tags?: Tag[];
  parent_a?: Plant;
  parent_b?: Plant;
}

export interface ActivityLogWithRelations extends ActivityLog {
  plant?: Plant;
  action_type?: ActionType;
  medium_used?: MediumOption;
  nutrient_type?: NutrientType;
}

export interface FinanceWithRelations extends Finance {
  category?: FinanceCategory;
  related_plant?: Plant;
}

export type FlushStatus = 'green' | 'yellow' | 'red';
export type RepotStatus = 'green' | 'yellow' | 'red';
